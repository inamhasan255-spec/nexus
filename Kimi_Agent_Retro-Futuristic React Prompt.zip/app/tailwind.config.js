/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive) / <alpha-value>)",
          foreground: "hsl(var(--destructive-foreground) / <alpha-value>)",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        // Retro-futuristic custom colors
        neon: {
          cyan: "#00F0FF",
          magenta: "#FF00A0",
          lime: "#39FF14",
        },
        void: {
          black: "#050508",
          purple: "#1A0B2E",
          grid: "#0A1929",
        },
        phosphor: {
          green: "#33FF00",
          amber: "#FFB800",
          silver: "#E0E0E0",
        },
      },
      fontFamily: {
        orbitron: ['Orbitron', 'sans-serif'],
        rajdhani: ['Rajdhani', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      borderRadius: {
        xl: "calc(var(--radius) + 4px)",
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
        xs: "calc(var(--radius) - 6px)",
      },
      boxShadow: {
        xs: "0 1px 2px 0 rgb(0 0 0 / 0.05)",
        neon: "0 0 10px #00F0FF, 0 0 20px #00F0FF, 0 0 40px rgba(0, 240, 255, 0.4)",
        "neon-magenta": "0 0 10px #FF00A0, 0 0 20px #FF00A0, 0 0 40px rgba(255, 0, 160, 0.4)",
        "neon-lime": "0 0 10px #39FF14, 0 0 20px #39FF14, 0 0 40px rgba(57, 255, 20, 0.4)",
        "neon-amber": "0 0 10px #FFB800, 0 0 20px #FFB800, 0 0 40px rgba(255, 184, 0, 0.4)",
        glow: "inset 0 0 20px rgba(0, 240, 255, 0.1)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "caret-blink": {
          "0%,70%,100%": { opacity: "1" },
          "20%,50%": { opacity: "0" },
        },
        "terminal-blink": {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0" },
        },
        "neon-pulse": {
          "0%, 100%": { 
            boxShadow: "0 0 10px #00F0FF, 0 0 20px #00F0FF, 0 0 40px rgba(0, 240, 255, 0.4)",
            opacity: "1"
          },
          "50%": { 
            boxShadow: "0 0 20px #00F0FF, 0 0 40px #00F0FF, 0 0 60px rgba(0, 240, 255, 0.6)",
            opacity: "0.9"
          },
        },
        "glitch": {
          "0%, 100%": { transform: "translateX(0)" },
          "20%": { transform: "translateX(-2px)" },
          "40%": { transform: "translateX(2px)" },
          "60%": { transform: "translateX(-1px)" },
          "80%": { transform: "translateX(1px)" },
        },
        "scanline": {
          "0%": { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(100%)" },
        },
        "flicker": {
          "0%, 100%": { opacity: "1" },
          "5%": { opacity: "0.95" },
          "10%": { opacity: "1" },
          "15%": { opacity: "0.98" },
          "20%": { opacity: "1" },
        },
        "wave": {
          "0%, 100%": { transform: "translateY(0) rotate(0deg)" },
          "25%": { transform: "translateY(-12px) rotate(-1deg)" },
          "75%": { transform: "translateY(6px) rotate(1deg)" },
        },
        "rotate-cube": {
          "0%": { transform: "rotateX(0deg) rotateY(0deg) rotateZ(0deg)" },
          "33%": { transform: "rotateX(120deg) rotateY(180deg) rotateZ(60deg)" },
          "66%": { transform: "rotateX(240deg) rotateY(360deg) rotateZ(120deg)" },
          "100%": { transform: "rotateX(360deg) rotateY(540deg) rotateZ(180deg)" },
        },
        "float": {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-10px)" },
        },
        "progress-fill": {
          "0%": { width: "0%" },
          "100%": { width: "100%" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "caret-blink": "caret-blink 1.25s ease-out infinite",
        "terminal-blink": "terminal-blink 0.8s step-end infinite",
        "neon-pulse": "neon-pulse 2s ease-in-out infinite",
        "glitch": "glitch 0.15s ease-in-out",
        "scanline": "scanline 8s linear infinite",
        "flicker": "flicker 4s ease-in-out infinite",
        "wave": "wave 2.4s ease-in-out infinite",
        "rotate-cube": "rotate-cube 8s linear infinite",
        "float": "float 3s ease-in-out infinite",
        "progress-fill": "progress-fill 0.3s ease-out forwards",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}
