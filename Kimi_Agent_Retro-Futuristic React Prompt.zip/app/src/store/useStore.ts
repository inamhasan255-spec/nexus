import { create } from 'zustand';

export type Theme = 'neon' | 'amber' | 'green';
export type Section = 'dashboard' | 'journal' | 'particles' | 'code' | 'biology' | 'books' | 'secure' | 'cube' | 'wave';

interface StoreState {
  // Boot sequence
  bootComplete: boolean;
  setBootComplete: (complete: boolean) => void;
  
  // Theme
  theme: Theme;
  setTheme: (theme: Theme) => void;
  
  // Current section
  currentSection: Section;
  setCurrentSection: (section: Section) => void;
  
  // Navigation hover
  navHover: string | null;
  setNavHover: (item: string | null) => void;
  
  // Global sound enabled
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  
  // CRT effects
  crtEnabled: boolean;
  setCrtEnabled: (enabled: boolean) => void;
  
  // Loading states
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
}

export const useStore = create<StoreState>((set) => ({
  bootComplete: false,
  setBootComplete: (complete) => set({ bootComplete: complete }),
  
  theme: 'neon',
  setTheme: (theme) => set({ theme }),
  
  currentSection: 'dashboard',
  setCurrentSection: (section) => set({ currentSection: section }),
  
  navHover: null,
  setNavHover: (item) => set({ navHover: item }),
  
  soundEnabled: false,
  setSoundEnabled: (enabled) => set({ soundEnabled: enabled }),
  
  crtEnabled: true,
  setCrtEnabled: (enabled) => set({ crtEnabled: enabled }),
  
  isLoading: false,
  setIsLoading: (loading) => set({ isLoading: loading }),
}));
