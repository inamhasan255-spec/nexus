import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface GlitchButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'terminal' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  disabled?: boolean;
  icon?: React.ReactNode;
}

export const GlitchButton: React.FC<GlitchButtonProps> = ({
  children,
  onClick,
  variant = 'primary',
  size = 'md',
  className = '',
  disabled = false,
  icon,
}) => {
  const [isGlitching, setIsGlitching] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const buttonRef = useRef<HTMLButtonElement>(null);

  const handleMouseEnter = () => {
    setIsHovered(true);
    setIsGlitching(true);
    setTimeout(() => setIsGlitching(false), 150);
  };

  const handleClick = () => {
    setIsGlitching(true);
    setTimeout(() => {
      setIsGlitching(false);
      onClick?.();
    }, 100);
  };

  const baseStyles = 'relative font-orbitron uppercase tracking-wider transition-all duration-200 overflow-hidden';
  
  const sizeStyles = {
    sm: 'px-4 py-2 text-xs',
    md: 'px-6 py-3 text-sm',
    lg: 'px-8 py-4 text-base',
  };

  const variantStyles = {
    primary: `
      bg-gradient-to-r from-neon-cyan/20 to-neon-magenta/20
      border border-neon-cyan/60 text-white
      hover:border-neon-cyan hover:shadow-neon
      hover:translate-y-[-2px]
      disabled:opacity-50 disabled:cursor-not-allowed
    `,
    secondary: `
      bg-transparent
      border border-neon-magenta/60 text-white
      hover:border-neon-magenta hover:shadow-neon-magenta
      hover:translate-y-[-2px]
      disabled:opacity-50 disabled:cursor-not-allowed
    `,
    terminal: `
      bg-transparent
      border border-phosphor-green/40 text-phosphor-green font-mono
      hover:bg-phosphor-green/10 hover:border-phosphor-green
      hover:shadow-[0_0_10px_rgba(51,255,0,0.3)]
      disabled:opacity-50 disabled:cursor-not-allowed
    `,
    danger: `
      bg-red-500/10
      border border-red-500/60 text-red-400
      hover:bg-red-500/20 hover:border-red-500
      hover:shadow-[0_0_10px_rgba(239,68,68,0.4)]
      disabled:opacity-50 disabled:cursor-not-allowed
    `,
  };

  return (
    <motion.button
      ref={buttonRef}
      className={`${baseStyles} ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleClick}
      disabled={disabled}
      whileTap={{ scale: 0.98 }}
      animate={isGlitching ? {
        x: [0, -2, 2, -1, 1, 0],
        skewX: [0, 2, -2, 0],
      } : {}}
      transition={{ duration: 0.15 }}
    >
      {/* Progress bar fill on hover */}
      <AnimatePresence>
        {isHovered && variant !== 'terminal' && (
          <motion.div
            className="absolute bottom-0 left-0 h-[2px] bg-current"
            initial={{ width: '0%' }}
            animate={{ width: '100%' }}
            exit={{ width: '0%' }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            style={{ 
              background: variant === 'primary' ? '#00F0FF' : variant === 'secondary' ? '#FF00A0' : '#ef4444'
            }}
          />
        )}
      </AnimatePresence>

      {/* Glitch overlay */}
      {isGlitching && (
        <>
          <motion.div
            className="absolute inset-0 bg-neon-cyan/20"
            initial={{ x: -5, opacity: 0 }}
            animate={{ x: 5, opacity: [0, 0.5, 0] }}
            transition={{ duration: 0.1 }}
          />
          <motion.div
            className="absolute inset-0 bg-neon-magenta/20"
            initial={{ x: 5, opacity: 0 }}
            animate={{ x: -5, opacity: [0, 0.5, 0] }}
            transition={{ duration: 0.1 }}
          />
        </>
      )}

      {/* Button content */}
      <span className="relative z-10 flex items-center justify-center gap-2">
        {icon && <span className="text-lg">{icon}</span>}
        {children}
      </span>

      {/* Corner accents */}
      <span className="absolute top-0 left-0 w-2 h-2 border-t border-l border-current opacity-60" />
      <span className="absolute top-0 right-0 w-2 h-2 border-t border-r border-current opacity-60" />
      <span className="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-current opacity-60" />
      <span className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-current opacity-60" />
    </motion.button>
  );
};
