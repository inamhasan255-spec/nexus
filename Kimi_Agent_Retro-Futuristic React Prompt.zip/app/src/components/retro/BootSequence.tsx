import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '@/store/useStore';
import { TerminalText, TerminalLog } from './TerminalText';

interface BootSequenceProps {
  onComplete?: () => void;
}

const BOOT_LINES = [
  '[OK] Initializing NEXUS kernel...',
  '[OK] Loading neural interface modules...',
  '[OK] Establishing secure connection...',
  '[OK] Memory banks online: 64TB',
  '[OK] Quantum processor: ACTIVE',
  '[OK] Holographic display: READY',
  '[OK] Biometric authentication: VERIFIED',
  '[WARN] Retro-futuristic aesthetic: ENGAGED',
  '[OK] All systems nominal',
];

export const BootSequence: React.FC<BootSequenceProps> = ({ onComplete }) => {
  const [phase, setPhase] = useState<'squeeze' | 'flicker' | 'terminal' | 'ready'>('squeeze');
  const [progress, setProgress] = useState(0);
  const { setBootComplete } = useStore();

  useEffect(() => {
    // Phase 1: Vertical squeeze (CRT turn on)
    const squeezeTimeout = setTimeout(() => {
      setPhase('flicker');
    }, 800);

    // Phase 2: Flicker and fade
    const flickerTimeout = setTimeout(() => {
      setPhase('terminal');
    }, 1500);

    // Phase 3: Terminal output
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 2;
      });
    }, 50);

    // Phase 4: Ready state
    const readyTimeout = setTimeout(() => {
      setPhase('ready');
    }, 4000);

    // Complete
    const completeTimeout = setTimeout(() => {
      setBootComplete(true);
      onComplete?.();
    }, 5500);

    return () => {
      clearTimeout(squeezeTimeout);
      clearTimeout(flickerTimeout);
      clearInterval(progressInterval);
      clearTimeout(readyTimeout);
      clearTimeout(completeTimeout);
    };
  }, [onComplete, setBootComplete]);

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-[10000] bg-void-black flex items-center justify-center"
        initial={{ opacity: 1 }}
        exit={{ 
          opacity: 0,
          scaleY: 0.01,
          transition: { duration: 0.5, ease: 'easeInOut' }
        }}
      >
        {/* Phase 1: Vertical squeeze effect */}
        {phase === 'squeeze' && (
          <motion.div
            className="w-full h-full bg-white"
            initial={{ scaleY: 0.01, opacity: 1 }}
            animate={{ scaleY: 1, opacity: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          />
        )}

        {/* Phase 2: Flicker */}
        {phase === 'flicker' && (
          <motion.div
            className="absolute inset-0 bg-void-black"
            animate={{ 
              opacity: [1, 0.9, 1, 0.8, 1, 0.95, 1],
            }}
            transition={{ duration: 0.5 }}
          />
        )}

        {/* Phase 3 & 4: Terminal output */}
        {(phase === 'terminal' || phase === 'ready') && (
          <motion.div
            className="w-full max-w-2xl px-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            {/* Header */}
            <div className="mb-8">
              <TerminalText 
                text="NEXUS SYSTEM v2.0.77" 
                speed={30}
                className="text-2xl font-bold"
              />
            </div>

            {/* Progress bar */}
            <div className="mb-6">
              <div className="h-2 bg-void-grid rounded-full overflow-hidden border border-neon-cyan/30">
                <motion.div
                  className="h-full bg-gradient-to-r from-neon-cyan to-neon-magenta"
                  initial={{ width: '0%' }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.1 }}
                  style={{
                    boxShadow: '0 0 10px #00F0FF, 0 0 20px #00F0FF',
                  }}
                />
              </div>
              <div className="mt-2 text-right font-mono text-sm text-neon-cyan/60">
                {progress}%
              </div>
            </div>

            {/* Boot log */}
            <div className="h-48 overflow-hidden">
              <TerminalLog lines={BOOT_LINES} lineDelay={200} />
            </div>

            {/* Ready message */}
            {phase === 'ready' && (
              <motion.div
                className="mt-8 text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <div className="text-4xl font-orbitron neon-text mb-4">
                  SYSTEM READY
                </div>
                <div className="font-mono text-phosphor-green/60 animate-pulse">
                  Press any key to continue...
                </div>
              </motion.div>
            )}
          </motion.div>
        )}

        {/* Scanline overlay during boot */}
        <div className="crt-overlay opacity-30" />
      </motion.div>
    </AnimatePresence>
  );
};
