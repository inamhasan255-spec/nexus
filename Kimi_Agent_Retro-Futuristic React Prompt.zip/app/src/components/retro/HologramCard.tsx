import React, { useRef, useState } from 'react';
import { motion } from 'framer-motion';

interface HologramCardProps {
  children: React.ReactNode;
  className?: string;
  glowColor?: string;
  tiltAmount?: number;
  onClick?: () => void;
}

export const HologramCard: React.FC<HologramCardProps> = ({
  children,
  className = '',
  glowColor = '#00F0FF',
  tiltAmount = 10,
  onClick,
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    
    const rect = cardRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    const mouseX = e.clientX - centerX;
    const mouseY = e.clientY - centerY;
    
    const rotateXValue = (mouseY / (rect.height / 2)) * -tiltAmount;
    const rotateYValue = (mouseX / (rect.width / 2)) * tiltAmount;
    
    setRotateX(rotateXValue);
    setRotateY(rotateYValue);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
    setIsHovered(false);
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  return (
    <motion.div
      ref={cardRef}
      className={`relative cursor-pointer ${className}`}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onMouseEnter={handleMouseEnter}
      onClick={onClick}
      style={{
        perspective: '1000px',
        transformStyle: 'preserve-3d',
      }}
      animate={{
        rotateX,
        rotateY,
      }}
      transition={{
        type: 'spring',
        stiffness: 300,
        damping: 30,
      }}
    >
      {/* Card content */}
      <div 
        className="relative w-full h-full rounded-lg overflow-hidden"
        style={{
          background: 'rgba(26, 11, 46, 0.8)',
          backdropFilter: 'blur(10px)',
          border: `1px solid ${glowColor}40`,
          boxShadow: isHovered 
            ? `0 0 20px ${glowColor}40, 0 0 40px ${glowColor}20, inset 0 0 20px ${glowColor}10`
            : `0 0 10px ${glowColor}20`,
          transition: 'box-shadow 0.3s ease',
        }}
      >
        {children}
      </div>

      {/* Animated border gradient */}
      {isHovered && (
        <motion.div
          className="absolute inset-0 rounded-lg pointer-events-none"
          style={{
            background: `conic-gradient(from 0deg, transparent, ${glowColor}40, transparent, ${glowColor}40, transparent)`,
            padding: '1px',
            mask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
            maskComposite: 'exclude',
            WebkitMaskComposite: 'xor',
          }}
          animate={{ rotate: 360 }}
          transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
        />
      )}

      {/* Scanline effect on hover */}
      {isHovered && (
        <motion.div
          className="absolute inset-0 pointer-events-none overflow-hidden rounded-lg"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="w-full h-[2px] bg-gradient-to-r from-transparent via-current to-transparent"
            style={{ color: glowColor }}
            animate={{ top: ['0%', '100%'] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
          />
        </motion.div>
      )}

      {/* Corner accents */}
      <div 
        className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 pointer-events-none"
        style={{ borderColor: glowColor }}
      />
      <div 
        className="absolute -top-1 -right-1 w-3 h-3 border-t-2 border-r-2 pointer-events-none"
        style={{ borderColor: glowColor }}
      />
      <div 
        className="absolute -bottom-1 -left-1 w-3 h-3 border-b-2 border-l-2 pointer-events-none"
        style={{ borderColor: glowColor }}
      />
      <div 
        className="absolute -bottom-1 -right-1 w-3 h-3 border-b-2 border-r-2 pointer-events-none"
        style={{ borderColor: glowColor }}
      />
    </motion.div>
  );
};
