import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface StarfieldProps {
  count?: number;
  speed?: number;
}

const StarParticles: React.FC<StarfieldProps> = ({ count = 2000, speed = 0.02 }) => {
  const pointsRef = useRef<THREE.Points>(null);
  const mouseRef = useRef({ x: 0, y: 0 });

  // Generate star positions
  const geometry = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const sizes = new Float32Array(count);

    const palette = [
      new THREE.Color('#00F0FF'), // cyan
      new THREE.Color('#FF00A0'), // magenta
      new THREE.Color('#39FF14'), // lime
      new THREE.Color('#e8c97a'), // gold
    ];

    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      
      // Spherical distribution
      const r = 3 + Math.random() * 4;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      
      positions[i3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i3 + 2] = (Math.random() - 0.5) * 6;

      // Random color from palette
      const color = palette[Math.floor(Math.random() * palette.length)];
      colors[i3] = color.r;
      colors[i3 + 1] = color.g;
      colors[i3 + 2] = color.b;

      // Random size
      sizes[i] = Math.random() * 1.5 + 0.5;
    }

    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geo.setAttribute('size', new THREE.BufferAttribute(sizes, 1));

    return geo;
  }, [count]);

  // Mouse tracking
  React.useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      mouseRef.current.y = -(e.clientY / window.innerHeight) * 2 + 1;
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Animation
  useFrame((state, delta) => {
    if (!pointsRef.current) return;

    const time = state.clock.elapsedTime;
    const positions = pointsRef.current.geometry.attributes.position.array as Float32Array;

    // Rotate entire field
    pointsRef.current.rotation.y += speed * delta;
    pointsRef.current.rotation.x = Math.sin(time * 0.1) * 0.1;

    // Subtle wave motion for individual stars
    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      positions[i3 + 1] += Math.sin(time * 0.5 + i * 0.01) * 0.001;
    }

    pointsRef.current.geometry.attributes.position.needsUpdate = true;

    // Camera follows mouse slightly
    state.camera.position.x += (mouseRef.current.x * 0.3 - state.camera.position.x) * 0.02;
    state.camera.position.y += (mouseRef.current.y * 0.15 - state.camera.position.y) * 0.02;
    state.camera.lookAt(0, 0, 0);
  });

  return (
    <points ref={pointsRef} geometry={geometry}>
      <pointsMaterial
        size={0.03}
        vertexColors
        transparent
        opacity={0.8}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};

// Connecting lines near cursor
const ConnectionLines: React.FC = () => {
  const linesRef = useRef<THREE.LineSegments>(null);

  useFrame(() => {
    if (!linesRef.current) return;
    linesRef.current.rotation.y += 0.001;
  });

  // Create constellation lines
  const lineGeometry = useMemo(() => {
    const points: THREE.Vector3[] = [];
    const numStars = 20;
    
    for (let i = 0; i < numStars; i++) {
      const angle = (i / numStars) * Math.PI * 2;
      const radius = 1.5 + Math.random() * 0.5;
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius;
      const z = (Math.random() - 0.5) * 0.5;
      
      points.push(new THREE.Vector3(x, y, z));
      
      // Connect to next star
      if (i > 0) {
        points.push(points[points.length - 2]);
        points.push(new THREE.Vector3(x, y, z));
      }
    }
    
    // Close the loop
    points.push(points[points.length - 1]);
    points.push(points[0]);

    return new THREE.BufferGeometry().setFromPoints(points);
  }, []);

  return (
    <lineSegments ref={linesRef} geometry={lineGeometry}>
      <lineBasicMaterial 
        color="#00F0FF" 
        transparent 
        opacity={0.2}
        blending={THREE.AdditiveBlending}
      />
    </lineSegments>
  );
};

export const Starfield: React.FC<StarfieldProps> = ({ count = 2000, speed = 0.02 }) => {
  return (
    <div className="fixed inset-0 z-0">
      <Canvas
        camera={{ position: [0, 0, 5], fov: 60 }}
        dpr={[1, 2]}
        gl={{ 
          antialias: false,
          alpha: true,
          powerPreference: 'high-performance',
        }}
      >
        <StarParticles count={count} speed={speed} />
        <ConnectionLines />
      </Canvas>
    </div>
  );
};
