import React from 'react';
import { motion } from 'framer-motion';
import { useStore, type Section, type Theme } from '@/store/useStore';

interface NavItem {
  id: Section;
  label: string;
  color: string;
  icon: string;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', color: '#00F0FF', icon: '◈' },
  { id: 'journal', label: 'Journal', color: '#e8c97a', icon: '✦' },
  { id: 'particles', label: 'Particles', color: '#00d4ff', icon: '◎' },
  { id: 'code', label: 'Code Vault', color: '#8b7cf6', icon: '</>' },
  { id: 'biology', label: 'Biology AI', color: '#4ade80', icon: '🧬' },
  { id: 'books', label: 'Books', color: '#f59e0b', icon: '📚' },
  { id: 'secure', label: 'Secure', color: '#ef4444', icon: '🔒' },
  { id: 'cube', label: '3D Cube', color: '#39FF14', icon: '⬡' },
  { id: 'wave', label: 'Wave Text', color: '#FF00A0', icon: '〜' },
];

const THEMES: { id: Theme; label: string; color: string }[] = [
  { id: 'neon', label: 'NEON', color: '#00F0FF' },
  { id: 'amber', label: 'AMBER', color: '#FFB800' },
  { id: 'green', label: 'PHOSPHOR', color: '#33FF00' },
];

export const Navigation: React.FC = () => {
  const { currentSection, setCurrentSection, theme, setTheme } = useStore();

  return (
    <motion.nav
      className="fixed top-4 left-4 right-4 z-[100] h-16 rounded-lg overflow-hidden"
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, delay: 0.2, ease: 'easeOut' }}
      style={{
        background: 'rgba(26, 11, 46, 0.85)',
        backdropFilter: 'blur(20px)',
        border: '1px solid rgba(0, 240, 255, 0.3)',
        boxShadow: '0 0 20px rgba(0, 240, 255, 0.15)',
      }}
    >
      {/* Scanline overlay */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-10"
        style={{
          background: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0, 240, 255, 0.03) 2px, rgba(0, 240, 255, 0.03) 4px)',
        }}
      />

      <div className="relative h-full flex items-center justify-between px-4">
        {/* Logo */}
        <motion.div 
          className="flex items-center gap-3"
          whileHover={{ scale: 1.02 }}
        >
          <span className="font-orbitron text-xl font-bold neon-text tracking-wider">
            NEXUS
          </span>
          <span className="font-mono text-xs text-neon-cyan/50 hidden sm:inline">
            v2.0.77
          </span>
        </motion.div>

        {/* Nav Items */}
        <div className="hidden lg:flex items-center gap-1">
          {NAV_ITEMS.map((item) => (
            <NavButton
              key={item.id}
              item={item}
              isActive={currentSection === item.id}
              onClick={() => setCurrentSection(item.id)}
            />
          ))}
        </div>

        {/* Mobile menu button */}
        <div className="lg:hidden">
          <select
            value={currentSection}
            onChange={(e) => setCurrentSection(e.target.value as Section)}
            className="bg-void-purple border border-neon-cyan/30 text-white font-mono text-sm rounded px-3 py-2 focus:outline-none focus:border-neon-cyan"
          >
            {NAV_ITEMS.map((item) => (
              <option key={item.id} value={item.id}>
                {item.icon} {item.label}
              </option>
            ))}
          </select>
        </div>

        {/* Theme toggle */}
        <div className="flex items-center gap-2">
          <div className="hidden md:flex items-center gap-1 bg-void-black/50 rounded-lg p-1">
            {THEMES.map((t) => (
              <button
                key={t.id}
                onClick={() => setTheme(t.id)}
                className={`px-2 py-1 text-xs font-mono rounded transition-all duration-200 ${
                  theme === t.id 
                    ? 'text-white' 
                    : 'text-white/40 hover:text-white/70'
                }`}
                style={{
                  background: theme === t.id ? `${t.color}30` : 'transparent',
                  border: theme === t.id ? `1px solid ${t.color}` : '1px solid transparent',
                  boxShadow: theme === t.id ? `0 0 10px ${t.color}40` : 'none',
                }}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </motion.nav>
  );
};

interface NavButtonProps {
  item: NavItem;
  isActive: boolean;
  onClick: () => void;
}

const NavButton: React.FC<NavButtonProps> = ({ item, isActive, onClick }) => {
  return (
    <motion.button
      onClick={onClick}
      className="relative px-3 py-2 font-rajdhani text-sm font-medium transition-all duration-200 nav-progress"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.98 }}
    >
      {/* Background glow when active */}
      {isActive && (
        <motion.div
          className="absolute inset-0 rounded-md"
          layoutId="navActive"
          style={{
            background: `${item.color}20`,
            border: `1px solid ${item.color}`,
            boxShadow: `0 0 15px ${item.color}40`,
          }}
          transition={{ type: 'spring', stiffness: 400, damping: 30 }}
        />
      )}

      {/* Content */}
      <span 
        className="relative z-10 flex items-center gap-2"
        style={{ color: isActive ? item.color : 'rgba(255,255,255,0.6)' }}
      >
        <span className="text-xs">{item.icon}</span>
        <span className="hidden xl:inline">{item.label}</span>
      </span>

      {/* Status dot */}
      <motion.span
        className="absolute -top-1 -right-1 w-2 h-2 rounded-full"
        style={{ background: item.color }}
        animate={isActive ? { 
          scale: [1, 1.2, 1],
          opacity: [1, 0.7, 1],
        } : {}}
        transition={{ duration: 1.5, repeat: Infinity }}
      />
    </motion.button>
  );
};
