import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

interface TerminalTextProps {
  text: string;
  speed?: number;
  scramble?: boolean;
  prompt?: string;
  className?: string;
  onComplete?: () => void;
  showCursor?: boolean;
}

const SCRAMBLE_CHARS = '<>[]{}//\\|*#@$%&!=?~';

export const TerminalText: React.FC<TerminalTextProps> = ({
  text,
  speed = 50,
  scramble = false,
  prompt = '>',
  className = '',
  onComplete,
  showCursor = true,
}) => {
  const [displayText, setDisplayText] = useState('');
  const [isComplete, setIsComplete] = useState(false);
  const indexRef = useRef(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (scramble) {
      // Scramble effect
      let iterations = 0;
      const maxIterations = text.length * 3;
      
      intervalRef.current = setInterval(() => {
        setDisplayText(
          text
            .split('')
            .map((char, i) => {
              if (i < iterations / 3) return text[i];
              if (char === ' ') return ' ';
              return SCRAMBLE_CHARS[Math.floor(Math.random() * SCRAMBLE_CHARS.length)];
            })
            .join('')
        );
        
        iterations++;
        if (iterations >= maxIterations) {
          setDisplayText(text);
          setIsComplete(true);
          if (intervalRef.current) clearInterval(intervalRef.current);
          onComplete?.();
        }
      }, speed / 2);
    } else {
      // Typewriter effect
      intervalRef.current = setInterval(() => {
        if (indexRef.current < text.length) {
          setDisplayText(text.slice(0, indexRef.current + 1));
          indexRef.current++;
        } else {
          setIsComplete(true);
          if (intervalRef.current) clearInterval(intervalRef.current);
          onComplete?.();
        }
      }, speed);
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [text, speed, scramble, onComplete]);

  return (
    <span className={`font-mono ${className}`}>
      {prompt && <span className="text-neon-cyan mr-2">{prompt}</span>}
      <span className="phosphor-text">{displayText}</span>
      {showCursor && !isComplete && (
        <motion.span
          className="inline-block w-2 h-4 bg-phosphor-green ml-1 align-middle"
          animate={{ opacity: [1, 0] }}
          transition={{ duration: 0.5, repeat: Infinity }}
        />
      )}
      {showCursor && isComplete && (
        <motion.span
          className="inline-block w-2 h-4 bg-phosphor-green/50 ml-1 align-middle"
          animate={{ opacity: [0.5, 0] }}
          transition={{ duration: 0.8, repeat: Infinity }}
        />
      )}
    </span>
  );
};

// Multi-line terminal text
interface TerminalLogProps {
  lines: string[];
  lineDelay?: number;
  className?: string;
}

export const TerminalLog: React.FC<TerminalLogProps> = ({
  lines,
  lineDelay = 300,
  className = '',
}) => {
  const [visibleLines, setVisibleLines] = useState<number>(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setVisibleLines((prev) => {
        if (prev >= lines.length) {
          clearInterval(interval);
          return prev;
        }
        return prev + 1;
      });
    }, lineDelay);

    return () => clearInterval(interval);
  }, [lines.length, lineDelay]);

  return (
    <div className={`font-mono text-sm space-y-1 ${className}`}>
      {lines.slice(0, visibleLines).map((line, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.2 }}
          className="flex items-start gap-2"
        >
          <span className="text-neon-cyan/60">{`[${String(i + 1).padStart(3, '0')}]`}</span>
          <span className={line.startsWith('[OK]') ? 'text-neon-lime' : line.startsWith('[WARN]') ? 'text-phosphor-amber' : 'text-phosphor-green/80'}>
            {line}
          </span>
        </motion.div>
      ))}
    </div>
  );
};
