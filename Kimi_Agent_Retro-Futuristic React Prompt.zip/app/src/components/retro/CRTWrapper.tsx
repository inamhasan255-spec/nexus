import React, { useEffect, useRef } from 'react';
import { useStore } from '@/store/useStore';
import { motion } from 'framer-motion';

interface CRTWrapperProps {
  children: React.ReactNode;
}

export const CRTWrapper: React.FC<CRTWrapperProps> = ({ children }) => {
  const { crtEnabled, bootComplete } = useStore();
  const flickerRef = useRef<HTMLDivElement>(null);

  // Random flicker effect
  useEffect(() => {
    if (!crtEnabled || !bootComplete) return;
    
    const flicker = () => {
      if (flickerRef.current) {
        const opacity = 0.98 + Math.random() * 0.02;
        flickerRef.current.style.opacity = String(opacity);
      }
      const nextFlicker = 3000 + Math.random() * 5000;
      setTimeout(flicker, nextFlicker);
    };
    
    const timeout = setTimeout(flicker, 5000);
    return () => clearTimeout(timeout);
  }, [crtEnabled, bootComplete]);

  return (
    <div className="relative min-h-screen bg-void-black" ref={flickerRef}>
      {/* Main content */}
      {children}
      
      {/* CRT Scanline overlay */}
      {crtEnabled && (
        <>
          <div className="crt-overlay" />
          
          {/* Moving scanline */}
          <motion.div
            className="fixed inset-0 pointer-events-none z-[9998]"
            style={{
              background: 'linear-gradient(180deg, transparent 0%, rgba(0, 240, 255, 0.03) 50%, transparent 100%)',
              height: '4px',
            }}
            animate={{
              top: ['0%', '100%'],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: 'linear',
            }}
          />
        </>
      )}
      
      {/* Vignette effect */}
      <div 
        className="fixed inset-0 pointer-events-none z-[9997]"
        style={{
          background: 'radial-gradient(ellipse at center, transparent 50%, rgba(0, 0, 0, 0.5) 100%)',
        }}
      />
    </div>
  );
};
