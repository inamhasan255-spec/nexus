import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { GlitchButton } from '@/components/retro/GlitchButton';

interface Message {
  id: string;
  role: 'user' | 'ai';
  content: string;
  timestamp: number;
}

interface Topic {
  id: string;
  icon: string;
  name: string;
  questions: string[];
}

const TOPICS: Topic[] = [
  { id: 'cell', icon: '🧬', name: 'Cell Biology', questions: ['What is the cell membrane?', 'Explain mitosis vs meiosis', 'What do mitochondria do?'] },
  { id: 'gen', icon: '🧪', name: 'Genetics & DNA', questions: ['How does DNA replication work?', 'What is a gene mutation?', 'Explain Mendelian inheritance'] },
  { id: 'evo', icon: '🦎', name: 'Evolution', questions: ['What is natural selection?', "Explain Darwin's theory", 'What are fossil records?'] },
  { id: 'eco', icon: '🌿', name: 'Ecology', questions: ['What is a food chain?', 'Explain the nitrogen cycle', 'What is biodiversity?'] },
  { id: 'hum', icon: '🫀', name: 'Human Biology', questions: ['How does the heart pump blood?', 'Explain the nervous system', 'What is the immune response?'] },
  { id: 'pla', icon: '🌱', name: 'Plant Biology', questions: ['How does photosynthesis work?', 'What is transpiration?', 'Explain plant cell structure'] },
  { id: 'mic', icon: '🔬', name: 'Microbiology', questions: ['Bacteria vs viruses?', 'How do vaccines work?', 'What is CRISPR?'] },
  { id: 'bio', icon: '⚗️', name: 'Biochemistry', questions: ['What are enzymes?', 'Explain cellular respiration', 'What are proteins made of?'] },
];

const KNOWLEDGE_BASE: Record<string, string> = {
  'cell membrane': 'The <strong>cell membrane</strong> is a <strong>phospholipid bilayer</strong> — two layers with hydrophilic heads outside and hydrophobic tails inside. Embedded proteins act as channels and receptors. Described by the <strong>fluid mosaic model</strong>.',
  'mitosis': '<strong>Mitosis</strong> produces 2 identical daughter cells (same chromosomes). Stages: Prophase → Metaphase → Anaphase → Telophase. For growth.<br><br><strong>Meiosis</strong> produces 4 genetically unique cells with half the chromosomes — used for sexual reproduction.',
  'mitochondria': '<strong>Mitochondria</strong> produce <strong>ATP</strong> via cellular respiration. Their folded inner membranes called <strong>cristae</strong> maximize surface area for ATP synthesis. They contain their own DNA, supporting the <strong>endosymbiotic theory</strong>.',
  'dna replication': '<strong>Helicase</strong> unwinds the double helix, <strong>DNA polymerase</strong> adds complementary nucleotides (5\'→3\'), and <strong>ligase</strong> joins fragments. Each new molecule keeps one original strand — semi-conservative replication.',
  'mutation': 'A change in the DNA sequence. Types: point mutations (single base), insertions/deletions (frameshifts), chromosomal mutations. Causes: radiation, chemicals, replication errors.',
  'mendelian': '<strong>Law of Segregation</strong>: alleles separate during gamete formation. <strong>Law of Independent Assortment</strong>: genes on different chromosomes sort independently. Key terms: dominant, recessive, homozygous, heterozygous.',
  'natural selection': 'Individuals with advantageous traits survive and reproduce more. Over generations, beneficial alleles increase in frequency. Requires: variation, heredity, differential survival.',
  'photosynthesis': '6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂. <strong>Light reactions</strong> (thylakoid): capture light, produce ATP and NADPH. <strong>Calvin cycle</strong> (stroma): uses ATP+NADPH to fix CO₂ into glucose.',
  'enzyme': 'Biological catalysts that speed up reactions without being consumed. They have an <strong>active site</strong> for substrate binding. Affected by temperature and pH. Examples: amylase, pepsin, DNA polymerase.',
  'cellular respiration': '<strong>Glycolysis</strong> (cytoplasm, 2 ATP) → <strong>Krebs cycle</strong> (matrix) → <strong>Electron transport chain</strong> (~34 ATP). Total ~36-38 ATP per glucose. Anaerobic respiration produces only 2 ATP.',
  'food chain': 'Producers → Primary consumers → Secondary consumers → Tertiary consumers → Decomposers. Only ~10% of energy transfers between levels (10% rule).',
  'immune': '<strong>Innate</strong> (fast, non-specific): skin, phagocytes, inflammation. <strong>Adaptive</strong>: B cells make antibodies; cytotoxic T cells kill infected cells; memory cells enable faster future responses.',
};

const findAnswer = (query: string): string | null => {
  const lowerQuery = query.toLowerCase();
  for (const [key, answer] of Object.entries(KNOWLEDGE_BASE)) {
    if (lowerQuery.includes(key)) {
      return answer;
    }
  }
  return null;
};

export const BiologyAI: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'checking' | 'online' | 'offline'>('checking');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Simulate connection check
  useEffect(() => {
    const timeout = setTimeout(() => {
      setConnectionStatus('online');
    }, 1500);
    return () => clearTimeout(timeout);
  }, []);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (text: string = input) => {
    if (!text.trim()) return;

    const userMessage: Message = {
      id: `u${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response delay
    setTimeout(() => {
      const answer = findAnswer(text);
      const aiMessage: Message = {
        id: `a${Date.now()}`,
        role: 'ai',
        content: answer || 'I apologize, but I don\'t have specific information about that topic in my knowledge base. Try asking about cell biology, genetics, evolution, ecology, human biology, plant biology, microbiology, or biochemistry.',
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <section className="min-h-screen pt-24 px-4 pb-8">
      <div className="max-w-6xl mx-auto h-[calc(100vh-7rem)]">
        <div className="flex flex-col lg:flex-row gap-4 h-full">
          {/* Topics sidebar */}
          <motion.aside
            className="w-full lg:w-64 flex-shrink-0"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <div className="holographic-card rounded-lg p-4 h-full flex flex-col" style={{ borderColor: '#4ade8040' }}>
              <div className="flex items-center gap-2 mb-4">
                <span className="text-neon-lime">🧬</span>
                <h2 className="font-orbitron text-lg font-bold text-neon-lime">
                  BIOLOGY AI
                </h2>
              </div>

              <div className="flex-1 overflow-auto space-y-1">
                {TOPICS.map(topic => (
                  <button
                    key={topic.id}
                    onClick={() => handleSend(`Tell me about ${topic.name}`)}
                    className="w-full text-left px-3 py-2 rounded text-sm font-rajdhani text-white/70 hover:bg-neon-lime/10 hover:text-neon-lime transition-all flex items-center gap-2"
                  >
                    <span>{topic.icon}</span>
                    <span>{topic.name}</span>
                  </button>
                ))}
              </div>

              <div className="mt-4 pt-4 border-t border-white/10">
                <div className="flex justify-between text-center">
                  <div>
                    <div className="font-orbitron text-xl text-neon-lime">{messages.filter(m => m.role === 'user').length}</div>
                    <div className="font-mono text-xs text-white/40">QUESTIONS</div>
                  </div>
                  <div>
                    <div className="font-orbitron text-xl text-neon-lime">1</div>
                    <div className="font-mono text-xs text-white/40">SESSIONS</div>
                  </div>
                </div>
              </div>
            </div>
          </motion.aside>

          {/* Chat area */}
          <motion.main
            className="flex-1 holographic-card rounded-lg overflow-hidden flex flex-col"
            style={{ borderColor: '#4ade8040' }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-void-black/50">
              <div>
                <h3 className="font-orbitron text-lg text-neon-lime">🧬 Biology AI</h3>
                <p className="font-mono text-xs text-white/40">
                  {connectionStatus === 'checking' && 'Detecting connection...'}
                  {connectionStatus === 'online' && 'Online + Offline Mode'}
                  {connectionStatus === 'offline' && 'Offline Mode'}
                </p>
              </div>
              <div className={`px-3 py-1 rounded-full text-xs font-mono border ${
                connectionStatus === 'online'
                  ? 'border-neon-lime bg-neon-lime/10 text-neon-lime'
                  : connectionStatus === 'checking'
                  ? 'border-phosphor-amber bg-phosphor-amber/10 text-phosphor-amber'
                  : 'border-red-500 bg-red-500/10 text-red-400'
              }`}>
                {connectionStatus === 'checking' && '⏳ Checking...'}
                {connectionStatus === 'online' && '● ONLINE'}
                {connectionStatus === 'offline' && '● OFFLINE'}
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-auto p-4 space-y-4">
              {messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center">
                  <div className="text-4xl mb-4">🧬</div>
                  <h3 className="font-orbitron text-xl text-white/70 mb-2">
                    Welcome to Biology AI
                  </h3>
                  <p className="font-rajdhani text-white/50 max-w-md mb-6">
                    Ask any biology question or select a topic from the sidebar.
                    I can help with cell biology, genetics, evolution, and more.
                  </p>
                  <div className="flex flex-wrap justify-center gap-2">
                    {TOPICS[0].questions.slice(0, 3).map((q, i) => (
                      <button
                        key={i}
                        onClick={() => handleSend(q)}
                        className="px-3 py-2 rounded-full border border-white/20 text-sm font-rajdhani text-white/60 hover:border-neon-lime hover:text-neon-lime transition-all"
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <>
                  {messages.map((message, i) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm flex-shrink-0 ${
                        message.role === 'ai'
                          ? 'bg-neon-lime/10 border border-neon-lime/30'
                          : 'bg-neon-cyan/10 border border-neon-cyan/30'
                      }`}>
                        {message.role === 'ai' ? '🤖' : '👤'}
                      </div>
                      <div className={`max-w-[70%] px-4 py-3 rounded-lg font-rajdhani text-sm leading-relaxed ${
                        message.role === 'ai'
                          ? 'bg-void-black/50 border border-white/10 text-white/80'
                          : 'bg-neon-cyan/10 border border-neon-cyan/30 text-white'
                      }`}>
                        {message.role === 'ai' ? (
                          <div dangerouslySetInnerHTML={{ __html: message.content }} />
                        ) : (
                          message.content
                        )}
                      </div>
                    </motion.div>
                  ))}
                  {isTyping && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex gap-3"
                    >
                      <div className="w-8 h-8 rounded-full bg-neon-lime/10 border border-neon-lime/30 flex items-center justify-center text-sm">
                        🤖
                      </div>
                      <div className="px-4 py-3 rounded-lg bg-void-black/50 border border-white/10">
                        <div className="flex gap-1">
                          <span className="w-2 h-2 rounded-full bg-neon-lime animate-bounce" style={{ animationDelay: '0ms' }} />
                          <span className="w-2 h-2 rounded-full bg-neon-lime animate-bounce" style={{ animationDelay: '150ms' }} />
                          <span className="w-2 h-2 rounded-full bg-neon-lime animate-bounce" style={{ animationDelay: '300ms' }} />
                        </div>
                      </div>
                    </motion.div>
                  )}
                  <div ref={messagesEndRef} />
                </>
              )}
            </div>

            {/* Input area */}
            <div className="p-4 border-t border-white/10 bg-void-black/50">
              <div className="flex gap-3">
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask a biology question..."
                  rows={1}
                  className="flex-1 bg-void-black/50 border border-white/20 rounded-lg px-4 py-3 font-rajdhani text-white placeholder:text-white/30 focus:outline-none focus:border-neon-lime resize-none"
                  style={{ minHeight: '48px', maxHeight: '120px' }}
                />
                <GlitchButton
                  variant="primary"
                  onClick={() => handleSend()}
                  disabled={!input.trim() || isTyping}
                  icon="➤"
                >
                  SEND
                </GlitchButton>
              </div>
            </div>
          </motion.main>
        </div>
      </div>
    </section>
  );
};
