import React, { useEffect, useRef, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { GlitchButton } from '@/components/retro/GlitchButton';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  depth: number;
}

const COLOR_PALETTES = [
  ['#00F0FF', '#39FF14'], // Cyan + Lime
  ['#FF00A0', '#FFB800'], // Magenta + Amber
  ['#FF6E6E', '#FF9F00'], // Red + Orange
  ['#B06EFF', '#00F0FF'], // Purple + Cyan
];

export const ParticleField: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const mouseRef = useRef({ x: -9999, y: -9999 });
  
  const [showLines, setShowLines] = useState(true);
  const [isPaused, setIsPaused] = useState(false);
  const [particleCount, setParticleCount] = useState(80);
  const [colorIndex, setColorIndex] = useState(0);
  const [fps, setFps] = useState(60);
  const [lineCount, setLineCount] = useState(0);

  const lastTimeRef = useRef(0);

  // Initialize particles
  const initParticles = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    particlesRef.current = [];
    for (let i = 0; i < particleCount; i++) {
      particlesRef.current.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.6,
        vy: (Math.random() - 0.5) * 0.6,
        r: Math.random() * 2.5 + 1,
        depth: Math.random(),
      });
    }
  }, [particleCount]);

  // Resize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resize = () => {
      const rect = canvas.parentElement?.getBoundingClientRect();
      if (rect) {
        canvas.width = rect.width;
        canvas.height = rect.height;
        initParticles();
      }
    };

    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [initParticles]);

  // Mouse tracking
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      };
    };

    const handleMouseLeave = () => {
      mouseRef.current = { x: -9999, y: -9999 };
    };

    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  // Animation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const animate = (timestamp: number) => {
      // FPS calculation
      if (lastTimeRef.current > 0) {
        const dt = timestamp - lastTimeRef.current;
        const currentFps = Math.round(1000 / Math.max(dt, 1));
        setFps(Math.min(currentFps, 99));
      }
      lastTimeRef.current = timestamp;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const [c1, c2] = COLOR_PALETTES[colorIndex];
      let currentLineCount = 0;

      particlesRef.current.forEach((p, i) => {
        if (!isPaused) {
          // Mouse repel
          const dx = p.x - mouseRef.current.x;
          const dy = p.y - mouseRef.current.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 120 && dist > 1) {
            const force = (120 - dist) / 120 * 0.8;
            p.vx += (dx / dist) * force;
            p.vy += (dy / dist) * force;
          }

          // Dampen velocity
          p.vx *= 0.99;
          p.vy *= 0.99;

          // Max speed
          const speed = Math.sqrt(p.vx * p.vx + p.vy * p.vy);
          if (speed > 3) {
            p.vx = (p.vx / speed) * 3;
            p.vy = (p.vy / speed) * 3;
          }

          // Update position
          p.x += p.vx;
          p.y += p.vy;

          // Bounce off edges
          if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
          if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

          // Clamp to canvas
          p.x = Math.max(0, Math.min(canvas.width, p.x));
          p.y = Math.max(0, Math.min(canvas.height, p.y));
        }

        // Draw particle
        const alpha = 0.4 + p.depth * 0.6;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r * (0.5 + p.depth * 0.5), 0, Math.PI * 2);
        ctx.fillStyle = c1 + Math.round(alpha * 255).toString(16).padStart(2, '0');
        ctx.fill();

        // Draw lines
        if (showLines) {
          for (let j = i + 1; j < particlesRef.current.length; j++) {
            const q = particlesRef.current[j];
            const ldx = p.x - q.x;
            const ldy = p.y - q.y;
            const ldist = Math.sqrt(ldx * ldx + ldy * ldy);
            const maxDist = 130;

            if (ldist < maxDist) {
              currentLineCount++;
              const lineAlpha = (1 - ldist / maxDist) * 0.35;
              ctx.beginPath();
              ctx.moveTo(p.x, p.y);
              ctx.lineTo(q.x, q.y);

              const gradient = ctx.createLinearGradient(p.x, p.y, q.x, q.y);
              gradient.addColorStop(0, c1 + Math.round(lineAlpha * 255).toString(16).padStart(2, '0'));
              gradient.addColorStop(1, c2 + Math.round(lineAlpha * 255).toString(16).padStart(2, '0'));

              ctx.strokeStyle = gradient;
              ctx.lineWidth = 0.8;
              ctx.stroke();
            }
          }
        }
      });

      setLineCount(currentLineCount);
      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [showLines, isPaused, colorIndex]);

  // Reinitialize when particle count changes
  useEffect(() => {
    initParticles();
  }, [particleCount, initParticles]);

  const toggleDensity = () => {
    setParticleCount(prev => prev === 80 ? 160 : 80);
  };

  return (
    <section className="min-h-screen pt-24 px-4 pb-8 relative">
      {/* Canvas background */}
      <div className="absolute inset-0 pt-20">
        <canvas
          ref={canvasRef}
          className="w-full h-full"
        />
      </div>

      {/* UI Overlay */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-[calc(100vh-6rem)]">
        <motion.div
          className="text-center mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <span className="font-mono text-xs text-neon-cyan/60 tracking-[0.3em] mb-2 block">
            EFFECT 01
          </span>
          <h2 className="font-orbitron text-4xl md:text-6xl font-bold neon-text mb-4">
            PARTICLE FIELD
          </h2>
          <p className="font-rajdhani text-white/60 max-w-md mx-auto">
            Thousands of nodes floating in 3D space, connected by live edges.
            Move your mouse to repel the field.
          </p>
        </motion.div>

        {/* Controls */}
        <motion.div
          className="flex flex-wrap justify-center gap-3 mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <GlitchButton
            variant={showLines ? 'primary' : 'secondary'}
            size="sm"
            onClick={() => setShowLines(!showLines)}
            icon="✦"
          >
            {showLines ? 'HIDE LINES' : 'SHOW LINES'}
          </GlitchButton>

          <GlitchButton
            variant="secondary"
            size="sm"
            onClick={() => setColorIndex((colorIndex + 1) % COLOR_PALETTES.length)}
            icon="◈"
          >
            CYCLE COLOR
          </GlitchButton>

          <GlitchButton
            variant={particleCount === 160 ? 'primary' : 'secondary'}
            size="sm"
            onClick={toggleDensity}
            icon="⬡"
          >
            {particleCount === 160 ? 'FEWER' : 'MORE'} PARTICLES
          </GlitchButton>

          <GlitchButton
            variant={isPaused ? 'primary' : 'secondary'}
            size="sm"
            onClick={() => setIsPaused(!isPaused)}
            icon={isPaused ? '▶' : '⏸'}
          >
            {isPaused ? 'RESUME' : 'PAUSE'}
          </GlitchButton>
        </motion.div>

        {/* Stats */}
        <motion.div
          className="flex gap-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <StatBox label="Particles" value={particleCount} color="#00F0FF" />
          <StatBox label="Connections" value={lineCount} color="#FF00A0" />
          <StatBox label="FPS" value={fps} color="#39FF14" />
        </motion.div>
      </div>
    </section>
  );
};

interface StatBoxProps {
  label: string;
  value: number;
  color: string;
}

const StatBox: React.FC<StatBoxProps> = ({ label, value, color }) => (
  <div className="text-center px-6 py-4 rounded-lg" style={{
    background: 'rgba(26, 11, 46, 0.8)',
    border: `1px solid ${color}40`,
  }}>
    <div 
      className="font-orbitron text-2xl font-bold"
      style={{ color, textShadow: `0 0 10px ${color}` }}
    >
      {value}
    </div>
    <div className="font-mono text-xs text-white/50 uppercase tracking-wider mt-1">
      {label}
    </div>
  </div>
);
