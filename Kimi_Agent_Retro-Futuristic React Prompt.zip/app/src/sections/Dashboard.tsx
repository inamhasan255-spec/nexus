import React from 'react';
import { motion } from 'framer-motion';
import { GlitchButton } from '@/components/retro/GlitchButton';
import { TerminalText } from '@/components/retro/TerminalText';
import { useStore } from '@/store/useStore';

const SYSTEM_STATS = [
  { label: 'CPU', value: '99.9%', color: '#00F0FF' },
  { label: 'MEMORY', value: '64TB', color: '#FF00A0' },
  { label: 'UPTIME', value: '∞', color: '#39FF14' },
  { label: 'STATUS', value: 'ONLINE', color: '#e8c97a' },
];

export const Dashboard: React.FC = () => {
  const { setCurrentSection } = useStore();

  return (
    <section className="min-h-screen flex flex-col items-center justify-center relative px-4 pt-20">
      {/* Perspective grid floor */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div 
          className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[200%] h-[60%]"
          style={{
            perspective: '1000px',
            transformStyle: 'preserve-3d',
          }}
        >
          <motion.div
            className="w-full h-full"
            style={{
              transform: 'rotateX(60deg)',
              transformOrigin: 'center top',
              background: `
                linear-gradient(90deg, rgba(0, 240, 255, 0.1) 1px, transparent 1px),
                linear-gradient(rgba(0, 240, 255, 0.1) 1px, transparent 1px)
              `,
              backgroundSize: '50px 50px',
            }}
            animate={{
              backgroundPosition: ['0px 0px', '0px 50px'],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'linear',
            }}
          />
        </div>
      </div>

      {/* Main content */}
      <div className="relative z-10 text-center max-w-4xl mx-auto">
        {/* Label */}
        <motion.div
          className="mb-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <span className="font-mono text-xs text-neon-cyan/60 tracking-[0.3em]">
            WELCOME TO THE FUTURE
          </span>
        </motion.div>

        {/* Main title */}
        <motion.div
          className="mb-6"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <h1 className="font-orbitron text-6xl md:text-8xl font-bold neon-text tracking-wider">
            NEXUS
          </h1>
        </motion.div>

        {/* Subtitle */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        >
          <TerminalText 
            text="MULTI-TOOL OPERATING SYSTEM"
            speed={40}
            className="text-lg md:text-xl text-white/70"
          />
        </motion.div>

        {/* System stats */}
        <motion.div
          className="flex flex-wrap justify-center gap-4 md:gap-8 mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.8 }}
        >
          {SYSTEM_STATS.map((stat, i) => (
            <motion.div
              key={stat.label}
              className="text-center px-4 py-2 rounded-lg"
              style={{
                background: 'rgba(26, 11, 46, 0.6)',
                border: `1px solid ${stat.color}40`,
              }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.8 + i * 0.1 }}
              whileHover={{ 
                scale: 1.05,
                boxShadow: `0 0 20px ${stat.color}40`,
              }}
            >
              <div 
                className="font-orbitron text-xl md:text-2xl font-bold"
                style={{ color: stat.color, textShadow: `0 0 10px ${stat.color}` }}
              >
                {stat.value}
              </div>
              <div className="font-mono text-xs text-white/50 tracking-wider">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 1 }}
        >
          <GlitchButton
            size="lg"
            onClick={() => setCurrentSection('journal')}
            icon="▶"
          >
            INITIALIZE
          </GlitchButton>
        </motion.div>

        {/* Hint text */}
        <motion.div
          className="mt-8 font-mono text-xs text-white/30"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 1.2 }}
        >
          <span className="animate-pulse">Press any key to explore...</span>
        </motion.div>
      </div>

      {/* Floating geometric shapes */}
      <FloatingShapes />
    </section>
  );
};

const FloatingShapes: React.FC = () => {
  const shapes = [
    { icon: '◈', x: '10%', y: '20%', color: '#00F0FF', delay: 0 },
    { icon: '⬡', x: '85%', y: '30%', color: '#FF00A0', delay: 0.5 },
    { icon: '◎', x: '15%', y: '70%', color: '#39FF14', delay: 1 },
    { icon: '◇', x: '80%', y: '75%', color: '#e8c97a', delay: 1.5 },
  ];

  return (
    <>
      {shapes.map((shape, i) => (
        <motion.div
          key={i}
          className="absolute text-4xl opacity-20 pointer-events-none"
          style={{ 
            left: shape.x, 
            top: shape.y,
            color: shape.color,
            textShadow: `0 0 20px ${shape.color}`,
          }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ 
            opacity: 0.2,
            scale: 1,
            y: [0, -20, 0],
          }}
          transition={{
            opacity: { duration: 0.5, delay: shape.delay },
            scale: { duration: 0.5, delay: shape.delay },
            y: { duration: 4, repeat: Infinity, ease: 'easeInOut', delay: shape.delay },
          }}
        >
          {shape.icon}
        </motion.div>
      ))}
    </>
  );
};
