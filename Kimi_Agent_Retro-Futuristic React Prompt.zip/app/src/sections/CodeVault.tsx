import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { GlitchButton } from '@/components/retro/GlitchButton';
import { HologramCard } from '@/components/retro/HologramCard';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface CodeSnippet {
  id: string;
  name: string;
  language: string;
  description: string;
  code: string;
  createdAt: number;
}

const LANGUAGES = ['JavaScript', 'Python', 'HTML', 'CSS', 'TypeScript', 'Rust', 'Go', 'SQL', 'Bash'];

const LANGUAGE_COLORS: Record<string, string> = {
  JavaScript: '#f7df1e',
  Python: '#3776ab',
  HTML: '#e34c26',
  CSS: '#264de4',
  TypeScript: '#3178c6',
  Rust: '#dea584',
  Go: '#00add8',
  SQL: '#f29111',
  Bash: '#4eaa25',
};

export const CodeVault: React.FC = () => {
  const [snippets, setSnippets] = useState<CodeSnippet[]>([]);
  const [selectedSnippet, setSelectedSnippet] = useState<CodeSnippet | null>(null);
  const [filter, setFilter] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingSnippet, setEditingSnippet] = useState<CodeSnippet | null>(null);

  // Load snippets
  useEffect(() => {
    const saved = localStorage.getItem('nexus_codevault');
    if (saved) {
      try {
        setSnippets(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load snippets');
      }
    }
  }, []);

  const saveSnippets = (newSnippets: CodeSnippet[]) => {
    setSnippets(newSnippets);
    localStorage.setItem('nexus_codevault', JSON.stringify(newSnippets));
  };

  const handleSave = (snippet: Partial<CodeSnippet>) => {
    if (editingSnippet) {
      const updated = snippets.map(s =>
        s.id === editingSnippet.id ? { ...s, ...snippet } as CodeSnippet : s
      );
      saveSnippets(updated);
    } else {
      const newSnippet: CodeSnippet = {
        id: `c${Date.now()}`,
        name: snippet.name || 'Untitled',
        language: snippet.language || 'JavaScript',
        description: snippet.description || '',
        code: snippet.code || '',
        createdAt: Date.now(),
      };
      saveSnippets([newSnippet, ...snippets]);
      setSelectedSnippet(newSnippet);
    }
    setIsEditorOpen(false);
    setEditingSnippet(null);
  };

  const handleDelete = (id: string) => {
    if (confirm('Delete this snippet?')) {
      const updated = snippets.filter(s => s.id !== id);
      saveSnippets(updated);
      if (selectedSnippet?.id === id) {
        setSelectedSnippet(null);
      }
    }
  };

  const handleExport = () => {
    const blob = new Blob([JSON.stringify(snippets, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `code-vault-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const imported = JSON.parse(ev.target?.result as string);
        if (Array.isArray(imported)) {
          saveSnippets([...imported, ...snippets]);
          alert(`Imported ${imported.length} snippets`);
        }
      } catch (err) {
        alert('Invalid file format');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const filteredSnippets = snippets
    .filter(s => !filter || s.language === filter)
    .filter(s => 
      !searchQuery || 
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.code.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => b.createdAt - a.createdAt);

  const languageCounts = LANGUAGES.reduce((acc, lang) => {
    acc[lang] = snippets.filter(s => s.language === lang).length;
    return acc;
  }, {} as Record<string, number>);

  return (
    <section className="min-h-screen pt-24 px-4 pb-8">
      <div className="max-w-7xl mx-auto h-[calc(100vh-7rem)]">
        <div className="flex flex-col lg:flex-row gap-4 h-full">
          {/* Sidebar */}
          <motion.aside
            className="w-full lg:w-72 flex-shrink-0 flex flex-col gap-4"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            {/* Header */}
            <div className="holographic-card rounded-lg p-4">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-neon-cyan">&lt;/&gt;</span>
                <h2 className="font-orbitron text-xl font-bold text-neon-cyan">
                  CODE VAULT
                </h2>
              </div>
              <p className="font-mono text-xs text-white/50">
                {snippets.length} SNIPPETS // GITHUB READY
              </p>
            </div>

            {/* New snippet button */}
            <GlitchButton
              className="w-full"
              onClick={() => {
                setEditingSnippet(null);
                setIsEditorOpen(true);
              }}
              icon="+"
            >
              NEW SNIPPET
            </GlitchButton>

            {/* Search */}
            <div className="holographic-card rounded-lg p-3">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search snippets..."
                className="w-full bg-void-black/50 border border-white/20 rounded px-3 py-2 font-mono text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-neon-cyan"
              />
            </div>

            {/* Language filters */}
            <div className="holographic-card rounded-lg p-4 flex-1 overflow-auto">
              <h4 className="font-mono text-xs text-white/50 mb-3 uppercase tracking-wider">
                Languages
              </h4>
              <div className="space-y-1">
                <button
                  onClick={() => setFilter(null)}
                  className={`w-full text-left px-3 py-2 rounded text-sm font-mono transition-all ${
                    filter === null
                      ? 'bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/50'
                      : 'text-white/60 hover:bg-white/5'
                  }`}
                >
                  All ({snippets.length})
                </button>
                {LANGUAGES.map(lang => (
                  <button
                    key={lang}
                    onClick={() => setFilter(filter === lang ? null : lang)}
                    className={`w-full text-left px-3 py-2 rounded text-sm font-mono transition-all flex justify-between items-center ${
                      filter === lang
                        ? 'bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/50'
                        : 'text-white/60 hover:bg-white/5'
                    }`}
                  >
                    <span>{lang}</span>
                    <span className="text-xs text-white/30">{languageCounts[lang] || 0}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Import/Export */}
            <div className="flex gap-2">
              <GlitchButton variant="terminal" size="sm" className="flex-1" onClick={handleExport}>
                EXPORT
              </GlitchButton>
              <label className="flex-1">
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImport}
                  className="hidden"
                />
                <GlitchButton variant="terminal" size="sm" className="w-full">
                  IMPORT
                </GlitchButton>
              </label>
            </div>
          </motion.aside>

          {/* Main content */}
          <motion.main
            className="flex-1 holographic-card rounded-lg overflow-hidden flex flex-col"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            {selectedSnippet ? (
              <CodeEditor
                snippet={selectedSnippet}
                onSave={(updates) => handleSave({ ...selectedSnippet, ...updates })}
                onDelete={() => handleDelete(selectedSnippet.id)}
                onClose={() => setSelectedSnippet(null)}
              />
            ) : (
              <div className="flex-1 p-6">
                {filteredSnippets.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center">
                    <div className="text-4xl mb-4 opacity-30">💻</div>
                    <h3 className="font-orbitron text-xl text-white/70 mb-2">
                      No snippets found
                    </h3>
                    <p className="font-mono text-sm text-white/40">
                      Create a new snippet or select one from the sidebar
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {filteredSnippets.map((snippet, i) => (
                      <motion.div
                        key={snippet.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.05 }}
                      >
                        <SnippetCard
                          snippet={snippet}
                          onClick={() => setSelectedSnippet(snippet)}
                        />
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </motion.main>
        </div>
      </div>

      {/* Editor Dialog */}
      <Dialog open={isEditorOpen} onOpenChange={setIsEditorOpen}>
        <DialogContent className="bg-void-purple border-neon-cyan/30 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="font-orbitron text-xl">
              {editingSnippet ? 'EDIT SNIPPET' : 'NEW SNIPPET'}
            </DialogTitle>
          </DialogHeader>
          <SnippetEditor
            snippet={editingSnippet}
            onSave={handleSave}
            onCancel={() => {
              setIsEditorOpen(false);
              setEditingSnippet(null);
            }}
          />
        </DialogContent>
      </Dialog>
    </section>
  );
};

interface SnippetCardProps {
  snippet: CodeSnippet;
  onClick: () => void;
}

const SnippetCard: React.FC<SnippetCardProps> = ({ snippet, onClick }) => {
  const date = new Date(snippet.createdAt).toLocaleDateString('en', {
    month: 'short',
    day: 'numeric',
  });

  return (
    <HologramCard
      glowColor={LANGUAGE_COLORS[snippet.language] || '#00F0FF'}
      onClick={onClick}
      className="cursor-pointer"
    >
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-orbitron text-lg text-white truncate pr-4">
            {snippet.name || 'Untitled'}
          </h3>
          <span
            className="px-2 py-1 text-xs font-mono rounded"
            style={{
              background: `${LANGUAGE_COLORS[snippet.language]}20`,
              color: LANGUAGE_COLORS[snippet.language],
            }}
          >
            {snippet.language}
          </span>
        </div>
        {snippet.description && (
          <p className="font-rajdhani text-sm text-white/60 line-clamp-2 mb-2">
            {snippet.description}
          </p>
        )}
        <div className="font-mono text-xs text-white/40">{date}</div>
      </div>
    </HologramCard>
  );
};

interface CodeEditorProps {
  snippet: CodeSnippet;
  onSave: (updates: Partial<CodeSnippet>) => void;
  onDelete: () => void;
  onClose: () => void;
}

const CodeEditor: React.FC<CodeEditorProps> = ({ snippet, onSave, onDelete, onClose }) => {
  const [name, setName] = useState(snippet.name);
  const [language, setLanguage] = useState(snippet.language);
  const [description, setDescription] = useState(snippet.description);
  const [code, setCode] = useState(snippet.code);

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center justify-between p-4 border-b border-white/10">
        <div className="flex items-center gap-4">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onBlur={() => onSave({ name })}
            className="bg-transparent border-b border-white/20 font-orbitron text-lg text-white focus:outline-none focus:border-neon-cyan px-0 py-1"
          />
          <select
            value={language}
            onChange={(e) => {
              setLanguage(e.target.value);
              onSave({ language: e.target.value });
            }}
            className="bg-void-black border border-white/20 rounded px-2 py-1 font-mono text-sm text-neon-cyan focus:outline-none focus:border-neon-cyan"
          >
            {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>
        <div className="flex gap-2">
          <GlitchButton variant="terminal" size="sm" onClick={onClose}>
            CLOSE
          </GlitchButton>
          <GlitchButton variant="danger" size="sm" onClick={onDelete}>
            DELETE
          </GlitchButton>
        </div>
      </div>

      {/* Description */}
      <input
        type="text"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        onBlur={() => onSave({ description })}
        placeholder="Add a description..."
        className="w-full bg-void-black/30 border-b border-white/10 px-4 py-2 font-rajdhani text-sm text-white/70 placeholder:text-white/30 focus:outline-none focus:border-neon-cyan/50"
      />

      {/* Code area */}
      <div className="flex-1 relative">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          onBlur={() => onSave({ code })}
          placeholder="// Write your code here..."
          className="w-full h-full bg-void-black/50 p-4 font-mono text-sm text-phosphor-green placeholder:text-phosphor-green/30 focus:outline-none resize-none"
          spellCheck={false}
          style={{ lineHeight: '1.6' }}
        />
        {/* Line numbers */}
        <div className="absolute left-0 top-0 bottom-0 w-10 bg-void-black/80 border-r border-white/10 py-4 text-right pr-2 font-mono text-xs text-white/30 select-none">
          {code.split('\n').map((_, i) => (
            <div key={i}>{i + 1}</div>
          ))}
        </div>
      </div>

      {/* Status bar */}
      <div className="px-4 py-2 bg-void-black/50 border-t border-white/10 font-mono text-xs text-white/40 flex justify-between">
        <span>{code.length} chars</span>
        <span>{code.split('\n').length} lines</span>
        <span className="text-neon-lime">[OK] Saved</span>
      </div>
    </div>
  );
};

interface SnippetEditorProps {
  snippet: CodeSnippet | null;
  onSave: (snippet: Partial<CodeSnippet>) => void;
  onCancel: () => void;
}

const SnippetEditor: React.FC<SnippetEditorProps> = ({ snippet, onSave, onCancel }) => {
  const [name, setName] = useState(snippet?.name || '');
  const [language, setLanguage] = useState(snippet?.language || 'JavaScript');
  const [description, setDescription] = useState(snippet?.description || '');
  const [code, setCode] = useState(snippet?.code || '');

  const handleSave = () => {
    if (!name && !code) return;
    onSave({ name, language, description, code });
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-4">
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Snippet name..."
          className="flex-1 bg-void-black/50 border border-white/20 rounded px-3 py-2 font-orbitron text-white placeholder:text-white/30 focus:outline-none focus:border-neon-cyan"
        />
        <select
          value={language}
          onChange={(e) => setLanguage(e.target.value)}
          className="bg-void-black/50 border border-white/20 rounded px-3 py-2 font-mono text-sm text-neon-cyan focus:outline-none focus:border-neon-cyan"
        >
          {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
        </select>
      </div>

      <input
        type="text"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder="Description (optional)..."
        className="w-full bg-void-black/50 border border-white/20 rounded px-3 py-2 font-rajdhani text-white placeholder:text-white/30 focus:outline-none focus:border-neon-cyan"
      />

      <textarea
        value={code}
        onChange={(e) => setCode(e.target.value)}
        placeholder="// Paste or type your code here..."
        rows={10}
        className="w-full bg-void-black/50 border border-white/20 rounded px-3 py-2 font-mono text-sm text-phosphor-green placeholder:text-phosphor-green/30 focus:outline-none focus:border-neon-cyan resize-none"
        spellCheck={false}
      />

      <div className="flex justify-end gap-3">
        <GlitchButton variant="secondary" size="sm" onClick={onCancel}>
          CANCEL
        </GlitchButton>
        <GlitchButton variant="primary" size="sm" onClick={handleSave}>
          SAVE
        </GlitchButton>
      </div>
    </div>
  );
};
