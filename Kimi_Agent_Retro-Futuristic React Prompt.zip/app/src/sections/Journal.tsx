import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { HologramCard } from '@/components/retro/HologramCard';
import { GlitchButton } from '@/components/retro/GlitchButton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface JournalEntry {
  id: string;
  title: string;
  body: string;
  mood: string;
  color: string;
  pinned: boolean;
  createdAt: number;
  date: string;
}

const MOODS = ['😊 Happy', '🤩 Excited', '😐 Neutral', '😢 Sad', '😰 Anxient'];
const COLORS = [
  { value: '#e8c97a', label: 'Gold' },
  { value: '#f59e8b', label: 'Peach' },
  { value: '#8b7cf6', label: 'Violet' },
  { value: '#6ee7b7', label: 'Mint' },
  { value: '#93c5fd', label: 'Sky' },
  { value: '#f9a8d4', label: 'Rose' },
];

export const Journal: React.FC = () => {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<JournalEntry | null>(null);
  const [filter, setFilter] = useState({ mood: '', color: '' });
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Load entries from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('nexus_journal');
    if (saved) {
      try {
        setEntries(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load journal entries');
      }
    }
  }, []);

  // Save entries
  const saveEntries = (newEntries: JournalEntry[]) => {
    setEntries(newEntries);
    localStorage.setItem('nexus_journal', JSON.stringify(newEntries));
  };

  const handleSave = (entry: Partial<JournalEntry>) => {
    if (editingEntry) {
      const updated = entries.map(e => 
        e.id === editingEntry.id ? { ...e, ...entry } as JournalEntry : e
      );
      saveEntries(updated);
    } else {
      const newEntry: JournalEntry = {
        id: `j${Date.now()}`,
        title: entry.title || 'Untitled',
        body: entry.body || '',
        mood: entry.mood || '',
        color: entry.color || '',
        pinned: false,
        createdAt: Date.now(),
        date: new Date().toISOString().split('T')[0],
      };
      saveEntries([newEntry, ...entries]);
    }
    setIsEditorOpen(false);
    setEditingEntry(null);
  };

  const handleDelete = (id: string) => {
    if (confirm('Delete this entry?')) {
      saveEntries(entries.filter(e => e.id !== id));
    }
  };

  const handlePin = (id: string) => {
    saveEntries(entries.map(e => 
      e.id === id ? { ...e, pinned: !e.pinned } : e
    ));
  };

  const filteredEntries = entries
    .filter(e => !filter.mood || e.mood === filter.mood)
    .filter(e => !filter.color || e.color === filter.color)
    .sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || b.createdAt - a.createdAt);

  return (
    <section className="min-h-screen pt-24 px-4 pb-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center gap-3 mb-2">
            <span className="text-2xl">✦</span>
            <h2 className="font-orbitron text-3xl font-bold" style={{ color: '#e8c97a' }}>
              LUMINARY
            </h2>
          </div>
          <p className="font-mono text-sm text-white/50">
            PRIVATE JOURNAL // {entries.length} ENTRIES
          </p>
        </motion.div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar */}
          <motion.aside
            className="w-full lg:w-64 flex-shrink-0"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div className="holographic-card rounded-lg p-4 space-y-4">
              {/* New Entry Button */}
              <GlitchButton
                className="w-full"
                onClick={() => {
                  setEditingEntry(null);
                  setIsEditorOpen(true);
                }}
                icon="+"
              >
                NEW ENTRY
              </GlitchButton>

              {/* Filters */}
              <div>
                <h4 className="font-mono text-xs text-white/50 mb-2 uppercase tracking-wider">
                  Mood Filter
                </h4>
                <div className="flex flex-wrap gap-2">
                  {MOODS.map(mood => (
                    <button
                      key={mood}
                      onClick={() => setFilter(f => ({ ...f, mood: f.mood === mood ? '' : mood }))}
                      className={`px-2 py-1 text-xs rounded-full border transition-all ${
                        filter.mood === mood 
                          ? 'border-neon-cyan bg-neon-cyan/20 text-neon-cyan' 
                          : 'border-white/20 text-white/50 hover:border-white/40'
                      }`}
                    >
                      {mood}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-mono text-xs text-white/50 mb-2 uppercase tracking-wider">
                  Color Label
                </h4>
                <div className="flex flex-wrap gap-2">
                  {COLORS.map(color => (
                    <button
                      key={color.value}
                      onClick={() => setFilter(f => ({ ...f, color: f.color === color.value ? '' : color.value }))}
                      className={`w-6 h-6 rounded-full border-2 transition-all ${
                        filter.color === color.value 
                          ? 'border-white scale-110' 
                          : 'border-transparent hover:scale-105'
                      }`}
                      style={{ background: color.value }}
                      title={color.label}
                    />
                  ))}
                </div>
              </div>

              {/* View toggle */}
              <div>
                <h4 className="font-mono text-xs text-white/50 mb-2 uppercase tracking-wider">
                  View
                </h4>
                <div className="flex gap-2">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`flex-1 py-2 text-xs font-mono rounded border transition-all ${
                      viewMode === 'grid'
                        ? 'border-neon-cyan bg-neon-cyan/20 text-neon-cyan'
                        : 'border-white/20 text-white/50'
                    }`}
                  >
                    ⊞ GRID
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`flex-1 py-2 text-xs font-mono rounded border transition-all ${
                      viewMode === 'list'
                        ? 'border-neon-cyan bg-neon-cyan/20 text-neon-cyan'
                        : 'border-white/20 text-white/50'
                    }`}
                  >
                    ☰ LIST
                  </button>
                </div>
              </div>
            </div>
          </motion.aside>

          {/* Main content */}
          <motion.main
            className="flex-1"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            {filteredEntries.length === 0 ? (
              <div className="holographic-card rounded-lg p-12 text-center">
                <div className="text-4xl mb-4 opacity-30">🌙</div>
                <h3 className="font-orbitron text-xl text-white/70 mb-2">No entries yet</h3>
                <p className="font-mono text-sm text-white/40">
                  Click "NEW ENTRY" to begin your journal
                </p>
              </div>
            ) : (
              <div className={viewMode === 'grid' 
                ? 'grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4' 
                : 'space-y-4'
              }>
                {filteredEntries.map((entry, i) => (
                  <motion.div
                    key={entry.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                  >
                    <EntryCard
                      entry={entry}
                      onClick={() => {
                        setEditingEntry(entry);
                        setIsEditorOpen(true);
                      }}
                      onDelete={() => handleDelete(entry.id)}
                      onPin={() => handlePin(entry.id)}
                    />
                  </motion.div>
                ))}
              </div>
            )}
          </motion.main>
        </div>
      </div>

      {/* Editor Dialog */}
      <Dialog open={isEditorOpen} onOpenChange={setIsEditorOpen}>
        <DialogContent className="bg-void-purple border-neon-cyan/30 max-w-2xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="font-orbitron text-xl">
              {editingEntry ? 'EDIT ENTRY' : 'NEW ENTRY'}
            </DialogTitle>
          </DialogHeader>
          <EntryEditor
            entry={editingEntry}
            onSave={handleSave}
            onCancel={() => {
              setIsEditorOpen(false);
              setEditingEntry(null);
            }}
          />
        </DialogContent>
      </Dialog>
    </section>
  );
};

interface EntryCardProps {
  entry: JournalEntry;
  onClick: () => void;
  onDelete: () => void;
  onPin: () => void;
}

const EntryCard: React.FC<EntryCardProps> = ({ entry, onClick, onDelete, onPin }) => {
  const wordCount = entry.body.trim() ? entry.body.trim().split(/\s+/).length : 0;
  const date = new Date(entry.createdAt).toLocaleDateString('en', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  return (
    <HologramCard
      glowColor={entry.color || '#00F0FF'}
      onClick={onClick}
      className="h-full"
    >
      <div className="p-4 h-full flex flex-col">
        {/* Color bar */}
        {entry.color && (
          <div 
            className="absolute top-0 left-0 right-0 h-1 rounded-t-lg"
            style={{ background: entry.color }}
          />
        )}

        {/* Pin indicator */}
        {entry.pinned && (
          <div className="absolute top-2 left-2 text-xs">📌</div>
        )}

        {/* Actions */}
        <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={(e) => { e.stopPropagation(); onPin(); }}
            className="w-6 h-6 rounded bg-void-black/80 border border-white/20 text-white/60 hover:text-neon-cyan hover:border-neon-cyan flex items-center justify-center text-xs"
          >
            📌
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); onDelete(); }}
            className="w-6 h-6 rounded bg-void-black/80 border border-white/20 text-white/60 hover:text-red-400 hover:border-red-400 flex items-center justify-center text-xs"
          >
            🗑
          </button>
        </div>

        {/* Content */}
        <div className="mt-2">
          <div className="font-mono text-xs text-white/40 mb-1">{date}</div>
          <h3 className={`font-orbitron text-lg mb-2 ${entry.title ? 'text-white' : 'text-white/40'}`}>
            {entry.title || 'Untitled'}
          </h3>
          <p className="font-rajdhani text-sm text-white/60 line-clamp-3 mb-3">
            {entry.body || 'Start writing...'}
          </p>
        </div>

        {/* Footer */}
        <div className="mt-auto flex items-center justify-between">
          {entry.mood ? (
            <span className="px-2 py-1 text-xs rounded-full bg-white/10 text-white/70">
              {entry.mood}
            </span>
          ) : <span />}
          <span className="font-mono text-xs text-white/40">{wordCount} words</span>
        </div>
      </div>
    </HologramCard>
  );
};

interface EntryEditorProps {
  entry: JournalEntry | null;
  onSave: (entry: Partial<JournalEntry>) => void;
  onCancel: () => void;
}

const EntryEditor: React.FC<EntryEditorProps> = ({ entry, onSave, onCancel }) => {
  const [title, setTitle] = useState(entry?.title || '');
  const [body, setBody] = useState(entry?.body || '');
  const [mood, setMood] = useState(entry?.mood || '');
  const [color, setColor] = useState(entry?.color || '');
  const [isPinned, setIsPinned] = useState(entry?.pinned || false);

  const handleSave = () => {
    if (!title && !body) return;
    onSave({ title, body, mood, color, pinned: isPinned });
  };

  return (
    <div className="space-y-4">
      {/* Title input */}
      <div>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Entry title..."
          className="w-full bg-void-black/50 border border-neon-cyan/30 rounded px-4 py-3 font-orbitron text-lg text-white placeholder:text-white/30 focus:outline-none focus:border-neon-cyan"
        />
      </div>

      {/* Mood & Color */}
      <div className="flex flex-wrap gap-4">
        <div className="flex-1 min-w-[200px]">
          <label className="font-mono text-xs text-white/50 mb-2 block">MOOD</label>
          <select
            value={mood}
            onChange={(e) => setMood(e.target.value)}
            className="w-full bg-void-black/50 border border-white/20 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-neon-cyan"
          >
            <option value="">— Select —</option>
            {MOODS.map(m => <option key={m} value={m}>{m}</option>)}
          </select>
        </div>
        <div>
          <label className="font-mono text-xs text-white/50 mb-2 block">COLOR</label>
          <div className="flex gap-2">
            {COLORS.map(c => (
              <button
                key={c.value}
                onClick={() => setColor(color === c.value ? '' : c.value)}
                className={`w-8 h-8 rounded-full border-2 transition-all ${
                  color === c.value ? 'border-white scale-110' : 'border-transparent'
                }`}
                style={{ background: c.value }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Body textarea */}
      <div>
        <textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder="Start writing your thoughts..."
          rows={10}
          className="w-full bg-void-black/50 border border-white/20 rounded px-4 py-3 font-rajdhani text-base text-white placeholder:text-white/30 focus:outline-none focus:border-neon-cyan resize-none"
        />
      </div>

      {/* Pin toggle */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setIsPinned(!isPinned)}
          className={`px-3 py-2 rounded border text-sm font-mono transition-all ${
            isPinned 
              ? 'border-neon-cyan bg-neon-cyan/20 text-neon-cyan' 
              : 'border-white/20 text-white/50'
          }`}
        >
          {isPinned ? '📌 PINNED' : '📌 PIN'}
        </button>
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
        <GlitchButton variant="secondary" size="sm" onClick={onCancel}>
          CANCEL
        </GlitchButton>
        <GlitchButton variant="primary" size="sm" onClick={handleSave}>
          SAVE
        </GlitchButton>
      </div>
    </div>
  );
};
