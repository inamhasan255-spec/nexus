import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { GlitchButton } from '@/components/retro/GlitchButton';

type SpeedMode = number;

const SPEEDS: { value: SpeedMode; label: string }[] = [
  { value: 0.4, label: 'SLOW' },
  { value: 1, label: 'NORMAL' },
  { value: 2.5, label: 'FAST' },
  { value: 6, label: 'CHAOS' },
];

const COLOR_PALETTES = [
  { name: 'White', colors: ['#f0f4ff', '#ffffff'] },
  { name: 'Neon', colors: ['#00F0FF', '#39FF14'] },
  { name: 'Sunset', colors: ['#FF00A0', '#FFB800'] },
  { name: 'Fire', colors: ['#FF6E6E', '#FF9F00'] },
];

const MAIN_TEXT = 'RETROFUTURE';
const SUB_TEXT = 'every letter has a soul';

export const WaveText: React.FC = () => {
  const [speed, setSpeed] = useState<SpeedMode>(1);
  const [colorIndex, setColorIndex] = useState(0);
  const [hoveredChar, setHoveredChar] = useState<number | null>(null);

  const currentColors = COLOR_PALETTES[colorIndex];
  const animationDuration = 2.4 / speed;

  return (
    <section className="min-h-screen pt-24 px-4 pb-8 flex flex-col items-center justify-center">
      {/* Background gradient */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(ellipse 80% 60% at 50% 50%, ${currentColors.colors[0]}10 0%, transparent 70%)`,
        }}
      />

      {/* Header */}
      <motion.div
        className="text-center mb-12 relative z-10"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <span className="font-mono text-xs text-neon-magenta/60 tracking-[0.3em] mb-2 block">
          EFFECT 02
        </span>
        <h2 className="font-orbitron text-4xl md:text-6xl font-bold neon-text-magenta mb-4">
          WAVE TEXT
        </h2>
        <p className="font-rajdhani text-white/60 max-w-md mx-auto">
          Each letter animates independently with a sine-wave offset.
          Hover a letter to light it up.
        </p>
      </motion.div>

      {/* Main wave text */}
      <motion.div
        className="relative z-10 mb-6"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <div className="flex justify-center flex-wrap gap-0">
          {MAIN_TEXT.split('').map((char, i) => (
            <motion.span
              key={i}
              className="inline-block font-orbitron text-5xl md:text-7xl lg:text-8xl font-bold cursor-default select-none px-[2px]"
              style={{
                color: hoveredChar === i ? currentColors.colors[1] : currentColors.colors[0],
                textShadow: hoveredChar === i 
                  ? `0 0 40px ${currentColors.colors[1]}, 0 0 80px ${currentColors.colors[1]}` 
                  : `0 0 20px ${currentColors.colors[0]}40`,
                transition: 'color 0.2s, text-shadow 0.2s',
              }}
              animate={{
                y: [0, -18, 0],
                rotate: [0, -2, 0, 1, 0],
              }}
              transition={{
                duration: animationDuration,
                repeat: Infinity,
                ease: 'easeInOut',
                delay: i * 0.1,
              }}
              onMouseEnter={() => setHoveredChar(i)}
              onMouseLeave={() => setHoveredChar(null)}
            >
              {char}
            </motion.span>
          ))}
        </div>
      </motion.div>

      {/* Subtitle wave */}
      <motion.div
        className="relative z-10 mb-12"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <div className="flex justify-center flex-wrap gap-0">
          {SUB_TEXT.split('').map((char, i) => (
            <motion.span
              key={i}
              className="inline-block font-rajdhani text-lg md:text-xl font-light text-white/50 px-[1px]"
              animate={{
                y: [0, -8, 0],
              }}
              transition={{
                duration: animationDuration * 1.25,
                repeat: Infinity,
                ease: 'easeInOut',
                delay: i * 0.05,
              }}
            >
              {char === ' ' ? '\u00a0' : char}
            </motion.span>
          ))}
        </div>
      </motion.div>

      {/* Controls */}
      <motion.div
        className="relative z-10 flex flex-wrap justify-center gap-3"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        {/* Speed buttons */}
        {SPEEDS.map((s) => (
          <GlitchButton
            key={s.label}
            variant={speed === s.value ? 'primary' : 'secondary'}
            size="sm"
            onClick={() => setSpeed(s.value)}
          >
            {s.label}
          </GlitchButton>
        ))}

        {/* Color cycle button */}
        <motion.button
          onClick={() => setColorIndex((colorIndex + 1) % COLOR_PALETTES.length)}
          className="px-4 py-2 rounded-full font-orbitron text-xs font-bold text-black"
          style={{
            background: `linear-gradient(90deg, ${currentColors.colors[0]}, ${currentColors.colors[1]})`,
          }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          🎨 CYCLE COLORS
        </motion.button>
      </motion.div>

      {/* Current settings */}
      <motion.div
        className="relative z-10 mt-8 font-mono text-xs text-white/30"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
      >
        <span className="text-white/50">Speed:</span> {SPEEDS.find(s => s.value === speed)?.label} | 
        <span className="text-white/50"> Colors:</span> {currentColors.name}
      </motion.div>
    </section>
  );
};
