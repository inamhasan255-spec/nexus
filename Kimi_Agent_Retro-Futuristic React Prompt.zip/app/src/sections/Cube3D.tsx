import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { GlitchButton } from '@/components/retro/GlitchButton';

type SpeedMode = 'slow' | 'normal' | 'fast';

const SPEED_CONFIG: Record<SpeedMode, { duration: number; rpm: string }> = {
  slow: { duration: 16, rpm: '3.7' },
  normal: { duration: 8, rpm: '7.5' },
  fast: { duration: 2, rpm: '30' },
};

const FACES = [
  { name: 'FRONT', icon: '⚡', color: '#00F0FF', transform: 'translateZ(110px)' },
  { name: 'BACK', icon: '🎯', color: '#FF00A0', transform: 'translateZ(-110px) rotateY(180deg)' },
  { name: 'RIGHT', icon: '🌿', color: '#39FF14', transform: 'rotateY(90deg) translateZ(110px)' },
  { name: 'LEFT', icon: '🔮', color: '#00F0FF', transform: 'rotateY(-90deg) translateZ(110px)' },
  { name: 'TOP', icon: '🌟', color: '#FF00A0', transform: 'rotateX(90deg) translateZ(110px)' },
  { name: 'BOTTOM', icon: '🔥', color: '#39FF14', transform: 'rotateX(-90deg) translateZ(110px)' },
];

export const Cube3D: React.FC = () => {
  const [isPaused, setIsPaused] = useState(false);
  const [speed, setSpeed] = useState<SpeedMode>('normal');
  const [isWireframe, setIsWireframe] = useState(false);

  const currentSpeed = SPEED_CONFIG[speed];

  return (
    <section className="min-h-screen pt-24 px-4 pb-8 flex flex-col items-center justify-center">
      {/* Header */}
      <motion.div
        className="text-center mb-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <span className="font-mono text-xs text-neon-lime/60 tracking-[0.3em] mb-2 block">
          EFFECT 03
        </span>
        <h2 className="font-orbitron text-4xl md:text-6xl font-bold neon-text-lime mb-4">
          CUBE ROTATION
        </h2>
        <p className="font-rajdhani text-white/60 max-w-md mx-auto">
          A 3D CSS cube tumbling through all axes simultaneously.
          Click the cube to pause it.
        </p>
      </motion.div>

      {/* Cube container */}
      <motion.div
        className="relative mb-12"
        style={{ perspective: '900px' }}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
      >
        <div
          className="relative w-[220px] h-[220px] cursor-pointer"
          style={{ transformStyle: 'preserve-3d' }}
          onClick={() => setIsPaused(!isPaused)}
        >
          <motion.div
            className="absolute inset-0"
            style={{ transformStyle: 'preserve-3d' }}
            animate={!isPaused ? {
              rotateX: [0, 360, 720, 1080],
              rotateY: [0, 180, 540, 900],
              rotateZ: [0, 60, 120, 180],
            } : {}}
            transition={{
              duration: currentSpeed.duration,
              repeat: Infinity,
              ease: 'linear',
            }}
          >
            {FACES.map((face) => (
              <div
                key={face.name}
                className="absolute w-[220px] h-[220px] border border-opacity-30 flex flex-col items-center justify-center font-orbitron text-lg tracking-wider backdrop-blur-sm transition-all duration-300"
                style={{
                  transform: face.transform,
                  borderColor: `${face.color}4d`,
                  color: face.color,
                  background: isWireframe 
                    ? 'transparent' 
                    : `${face.color}10`,
                  backdropFilter: isWireframe ? 'none' : 'blur(4px)',
                }}
              >
                <span className="text-4xl mb-2">{face.icon}</span>
                <span>{face.name}</span>
              </div>
            ))}
          </motion.div>
        </div>
      </motion.div>

      {/* Controls */}
      <motion.div
        className="flex flex-wrap justify-center gap-3 mb-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        <GlitchButton
          variant={speed === 'slow' ? 'primary' : 'secondary'}
          size="sm"
          onClick={() => setSpeed('slow')}
          icon="🐢"
        >
          SLOW
        </GlitchButton>

        <GlitchButton
          variant={speed === 'normal' ? 'primary' : 'secondary'}
          size="sm"
          onClick={() => setSpeed('normal')}
          icon="▶"
        >
          NORMAL
        </GlitchButton>

        <GlitchButton
          variant={speed === 'fast' ? 'primary' : 'secondary'}
          size="sm"
          onClick={() => setSpeed('fast')}
          icon="⚡"
        >
          FAST
        </GlitchButton>

        <GlitchButton
          variant={isWireframe ? 'primary' : 'secondary'}
          size="sm"
          onClick={() => setIsWireframe(!isWireframe)}
          icon="□"
        >
          WIREFRAME
        </GlitchButton>
      </motion.div>

      {/* Stats */}
      <motion.div
        className="flex gap-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
      >
        <StatBox label="RPM" value={currentSpeed.rpm} color="#39FF14" />
        <StatBox label="Axis" value="XYZ" color="#00F0FF" />
        <StatBox label="State" value={isPaused ? 'OFF' : 'ON'} color={isPaused ? '#ef4444' : '#39FF14'} />
      </motion.div>

      {/* Click hint */}
      <motion.p
        className="mt-8 font-mono text-xs text-white/30"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
      >
        Click the cube to {isPaused ? 'resume' : 'pause'} rotation
      </motion.p>
    </section>
  );
};

interface StatBoxProps {
  label: string;
  value: string;
  color: string;
}

const StatBox: React.FC<StatBoxProps> = ({ label, value, color }) => (
  <div 
    className="text-center px-6 py-4 rounded-lg"
    style={{
      background: 'rgba(26, 11, 46, 0.8)',
      border: `1px solid ${color}40`,
    }}
  >
    <div 
      className="font-orbitron text-2xl font-bold"
      style={{ color, textShadow: `0 0 10px ${color}` }}
    >
      {value}
    </div>
    <div className="font-mono text-xs text-white/50 uppercase tracking-wider mt-1">
      {label}
    </div>
  </div>
);
