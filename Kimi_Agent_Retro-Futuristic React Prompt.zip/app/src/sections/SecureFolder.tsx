import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { GlitchButton } from '@/components/retro/GlitchButton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface SecureNote {
  id: string;
  title: string;
  content: string;
  createdAt: number;
}

const DEFAULT_PASSWORD = 'nexus2026';

export const SecureFolder: React.FC = () => {
  const [isLocked, setIsLocked] = useState(true);
  const [password, setPassword] = useState('');
  const [attempts, setAttempts] = useState(0);
  const [isShaking, setIsShaking] = useState(false);
  const [notes, setNotes] = useState<SecureNote[]>([]);
  const [selectedNote, setSelectedNote] = useState<SecureNote | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<SecureNote | null>(null);

  // Load notes
  useEffect(() => {
    const saved = localStorage.getItem('nexus_secure_notes');
    if (saved) {
      try {
        setNotes(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load notes');
      }
    }
  }, []);

  const saveNotes = (newNotes: SecureNote[]) => {
    setNotes(newNotes);
    localStorage.setItem('nexus_secure_notes', JSON.stringify(newNotes));
  };

  const handleUnlock = () => {
    if (password === DEFAULT_PASSWORD) {
      setIsLocked(false);
      setAttempts(0);
    } else {
      setAttempts(a => a + 1);
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 400);
    }
  };

  const handleLock = () => {
    setIsLocked(true);
    setPassword('');
    setSelectedNote(null);
  };

  const handleSaveNote = (note: Partial<SecureNote>) => {
    if (editingNote) {
      const updated = notes.map(n =>
        n.id === editingNote.id ? { ...n, ...note } as SecureNote : n
      );
      saveNotes(updated);
    } else {
      const newNote: SecureNote = {
        id: `s${Date.now()}`,
        title: note.title || 'Untitled',
        content: note.content || '',
        createdAt: Date.now(),
      };
      saveNotes([newNote, ...notes]);
    }
    setIsEditorOpen(false);
    setEditingNote(null);
  };

  const handleDeleteNote = (id: string) => {
    if (confirm('Delete this secure note?')) {
      const updated = notes.filter(n => n.id !== id);
      saveNotes(updated);
      if (selectedNote?.id === id) {
        setSelectedNote(null);
      }
    }
  };

  if (isLocked) {
    return (
      <section className="min-h-screen pt-24 px-4 pb-8 flex items-center justify-center">
        <motion.div
          className="text-center"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          {/* Lock icon */}
          <motion.div
            className="text-8xl mb-6"
            animate={{
              scale: [1, 1.05, 1],
              filter: [
                'drop-shadow(0 0 24px rgba(239, 68, 68, 0.3))',
                'drop-shadow(0 0 40px rgba(239, 68, 68, 0.6))',
                'drop-shadow(0 0 24px rgba(239, 68, 68, 0.3))',
              ],
            }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            🔒
          </motion.div>

          {/* Title */}
          <h2 className="font-orbitron text-4xl font-bold text-red-500 mb-2">
            SECURE FOLDER
          </h2>
          <p className="font-mono text-sm text-white/50 mb-8 uppercase tracking-wider">
            Password Protected // Encrypted Storage
          </p>

          {/* Teaser cards */}
          <div className="flex justify-center gap-3 mb-8 opacity-30" style={{ filter: 'blur(6px)' }}>
            {[1, 2, 3].map((_, i) => (
              <div
                key={i}
                className="w-24 h-16 rounded-lg"
                style={{
                  background: `linear-gradient(135deg, rgba(239, 68, 68, ${0.3 - i * 0.1}), rgba(139, 124, 246, 0.1))`,
                  border: '1px solid rgba(239, 68, 68, 0.2)',
                }}
              />
            ))}
          </div>

          {/* Password input */}
          <motion.div
            className="max-w-sm mx-auto"
            animate={isShaking ? {
              x: [0, -8, 8, -8, 8, 0],
            } : {}}
            transition={{ duration: 0.4 }}
          >
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleUnlock()}
              placeholder="••••••••"
              maxLength={32}
              className="w-full bg-red-500/5 border border-red-500/30 rounded-xl px-4 py-3 font-mono text-lg text-center text-white placeholder:text-white/20 focus:outline-none focus:border-red-500 focus:shadow-[0_0_0_3px_rgba(239,68,68,0.1)] mb-4"
            />

            {attempts > 0 && (
              <p className="text-red-400 text-sm mb-4 font-mono">
                Invalid password. Attempts: {attempts}
              </p>
            )}

            <GlitchButton
              variant="danger"
              className="w-full"
              onClick={handleUnlock}
              icon="🔓"
            >
              UNLOCK FOLDER
            </GlitchButton>

            <p className="mt-4 text-white/30 text-xs font-mono">
              Hint: Default password is "nexus2026"
            </p>
          </motion.div>
        </motion.div>
      </section>
    );
  }

  return (
    <section className="min-h-screen pt-24 px-4 pb-8">
      <div className="max-w-7xl mx-auto h-[calc(100vh-7rem)]">
        <div className="flex flex-col lg:flex-row gap-4 h-full">
          {/* Sidebar */}
          <motion.aside
            className="w-full lg:w-72 flex-shrink-0 flex flex-col gap-4"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            {/* Header */}
            <div className="holographic-card rounded-lg p-4" style={{ borderColor: '#ef444440' }}>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-red-500">🔓</span>
                <h2 className="font-orbitron text-xl font-bold text-red-500">
                  SECURE FOLDER
                </h2>
              </div>
              <p className="font-mono text-xs text-white/50">
                {notes.length} SECRET NOTES // ENCRYPTED
              </p>
            </div>

            {/* New note button */}
            <GlitchButton
              className="w-full"
              variant="danger"
              onClick={() => {
                setEditingNote(null);
                setIsEditorOpen(true);
              }}
              icon="+"
            >
              NEW SECRET NOTE
            </GlitchButton>

            {/* Note list */}
            <div className="holographic-card rounded-lg p-4 flex-1 overflow-auto" style={{ borderColor: '#ef444440' }}>
              <div className="space-y-2">
                {notes.map(note => (
                  <button
                    key={note.id}
                    onClick={() => setSelectedNote(note)}
                    className={`w-full text-left p-3 rounded-lg border transition-all group ${
                      selectedNote?.id === note.id
                        ? 'border-red-500 bg-red-500/10'
                        : 'border-white/10 hover:border-red-500/50 hover:bg-red-500/5'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-rajdhani font-medium text-white truncate">
                        {note.title || 'Untitled'}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteNote(note.id);
                        }}
                        className="opacity-0 group-hover:opacity-100 w-6 h-6 rounded bg-red-500/20 border border-red-500/40 text-red-400 flex items-center justify-center text-xs hover:bg-red-500/30 transition-all"
                      >
                        🗑
                      </button>
                    </div>
                    <div className="font-mono text-xs text-white/40 mt-1">
                      {new Date(note.createdAt).toLocaleDateString()}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Lock button */}
            <GlitchButton variant="danger" onClick={handleLock} icon="🔒">
              LOCK FOLDER
            </GlitchButton>
          </motion.aside>

          {/* Main content */}
          <motion.main
            className="flex-1 holographic-card rounded-lg overflow-hidden flex flex-col"
            style={{ borderColor: '#ef444440' }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            {selectedNote ? (
              <>
                {/* Toolbar */}
                <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-void-black/50">
                  <input
                    type="text"
                    value={selectedNote.title}
                    onChange={(e) => {
                      const updated = { ...selectedNote, title: e.target.value };
                      setSelectedNote(updated);
                      handleSaveNote(updated);
                    }}
                    className="bg-transparent border-b border-transparent hover:border-white/20 focus:border-red-500 font-orbitron text-lg text-white focus:outline-none px-0 py-1"
                  />
                  <GlitchButton
                    variant="danger"
                    size="sm"
                    onClick={() => handleDeleteNote(selectedNote.id)}
                  >
                    DELETE
                  </GlitchButton>
                </div>

                {/* Content */}
                <textarea
                  value={selectedNote.content}
                  onChange={(e) => {
                    const updated = { ...selectedNote, content: e.target.value };
                    setSelectedNote(updated);
                    saveNotes(notes.map(n => n.id === updated.id ? updated : n));
                  }}
                  placeholder="Your secret notes..."
                  className="flex-1 bg-void-black/30 p-4 font-rajdhani text-white placeholder:text-white/30 focus:outline-none resize-none"
                />

                {/* Status bar */}
                <div className="px-4 py-2 border-t border-white/10 bg-void-black/50 font-mono text-xs text-white/40 flex justify-between items-center">
                  <span className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                    ENCRYPTED
                  </span>
                  <span>{selectedNote.content.length} chars</span>
                </div>
              </>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
                <div className="text-5xl mb-4 opacity-20">🔐</div>
                <h3 className="font-orbitron text-xl text-white/70 mb-2">
                  Select a note
                </h3>
                <p className="font-rajdhani text-white/50">
                  Your secrets stay here.
                </p>
              </div>
            )}
          </motion.main>
        </div>
      </div>

      {/* Editor Dialog */}
      <Dialog open={isEditorOpen} onOpenChange={setIsEditorOpen}>
        <DialogContent className="bg-void-purple border-red-500/30 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="font-orbitron text-xl text-red-500">
              {editingNote ? 'EDIT SECRET' : 'NEW SECRET NOTE'}
            </DialogTitle>
          </DialogHeader>
          <NoteEditor
            note={editingNote}
            onSave={handleSaveNote}
            onCancel={() => {
              setIsEditorOpen(false);
              setEditingNote(null);
            }}
          />
        </DialogContent>
      </Dialog>
    </section>
  );
};

interface NoteEditorProps {
  note: SecureNote | null;
  onSave: (note: Partial<SecureNote>) => void;
  onCancel: () => void;
}

const NoteEditor: React.FC<NoteEditorProps> = ({ note, onSave, onCancel }) => {
  const [title, setTitle] = useState(note?.title || '');
  const [content, setContent] = useState(note?.content || '');

  const handleSave = () => {
    if (!title && !content) return;
    onSave({ title, content });
  };

  return (
    <div className="space-y-4">
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Note title..."
        className="w-full bg-void-black/50 border border-white/20 rounded px-3 py-2 font-orbitron text-white placeholder:text-white/30 focus:outline-none focus:border-red-500"
      />

      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Your secret content..."
        rows={10}
        className="w-full bg-void-black/50 border border-white/20 rounded px-3 py-2 font-rajdhani text-white placeholder:text-white/30 focus:outline-none focus:border-red-500 resize-none"
      />

      <div className="flex justify-end gap-3">
        <GlitchButton variant="secondary" size="sm" onClick={onCancel}>
          CANCEL
        </GlitchButton>
        <GlitchButton variant="danger" size="sm" onClick={handleSave}>
          SAVE SECRET
        </GlitchButton>
      </div>
    </div>
  );
};
