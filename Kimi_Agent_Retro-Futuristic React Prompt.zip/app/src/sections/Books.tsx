import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { GlitchButton } from '@/components/retro/GlitchButton';


interface Book {
  id: string;
  name: string;
  content: string;
  size: number;
  createdAt: number;
}

type ReaderTheme = 'dark' | 'light' | 'sepia';

export const Books: React.FC = () => {
  const [books, setBooks] = useState<Book[]>([]);
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [readerTheme, setReaderTheme] = useState<ReaderTheme>('dark');
  const [fontSize, setFontSize] = useState(16);
  const [scrollProgress, setScrollProgress] = useState(0);
  const contentRef = useRef<HTMLDivElement>(null);

  // Load books
  useEffect(() => {
    const saved = localStorage.getItem('nexus_books');
    if (saved) {
      try {
        setBooks(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load books');
      }
    }
  }, []);

  const saveBooks = (newBooks: Book[]) => {
    setBooks(newBooks);
    localStorage.setItem('nexus_books', JSON.stringify(newBooks));
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      const content = ev.target?.result as string;
      const newBook: Book = {
        id: `b${Date.now()}`,
        name: file.name.replace(/\.[^/.]+$/, ''),
        content,
        size: content.length,
        createdAt: Date.now(),
      };
      saveBooks([newBook, ...books]);
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleDelete = (id: string) => {
    if (confirm('Delete this book?')) {
      const updated = books.filter(b => b.id !== id);
      saveBooks(updated);
      if (selectedBook?.id === id) {
        setSelectedBook(null);
      }
    }
  };

  const handleScroll = () => {
    if (contentRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = contentRef.current;
      const progress = (scrollTop / (scrollHeight - clientHeight)) * 100;
      setScrollProgress(progress);
    }
  };

  const filteredBooks = books.filter(b =>
    b.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const themeStyles: Record<ReaderTheme, React.CSSProperties> = {
    dark: {
      background: '#050508',
      color: '#e8ecf5',
    },
    light: {
      background: '#f5f0e8',
      color: '#1a1612',
    },
    sepia: {
      background: '#f5edd8',
      color: '#3d2b1f',
    },
  };

  return (
    <section className="min-h-screen pt-24 px-4 pb-8">
      <div className="max-w-7xl mx-auto h-[calc(100vh-7rem)]">
        <div className="flex flex-col lg:flex-row gap-4 h-full">
          {/* Sidebar */}
          <motion.aside
            className="w-full lg:w-72 flex-shrink-0 flex flex-col gap-4"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            {/* Header */}
            <div className="holographic-card rounded-lg p-4" style={{ borderColor: '#f59e0b40' }}>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-phosphor-amber">📚</span>
                <h2 className="font-orbitron text-xl font-bold text-phosphor-amber">
                  BIBLIOTHECA
                </h2>
              </div>
              <p className="font-mono text-xs text-white/50">
                {books.length} BOOKS // PRIVATE LIBRARY
              </p>
            </div>

            {/* Import button */}
            <label>
              <input
                type="file"
                accept=".txt,.md"
                onChange={handleImport}
                className="hidden"
              />
              <GlitchButton className="w-full" icon="📂">
                IMPORT BOOK
              </GlitchButton>
            </label>

            {/* Search */}
            <div className="holographic-card rounded-lg p-3" style={{ borderColor: '#f59e0b40' }}>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search books..."
                className="w-full bg-void-black/50 border border-white/20 rounded px-3 py-2 font-mono text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-phosphor-amber"
              />
            </div>

            {/* Book list */}
            <div className="holographic-card rounded-lg p-4 flex-1 overflow-auto" style={{ borderColor: '#f59e0b40' }}>
              <div className="space-y-2">
                {filteredBooks.map(book => (
                  <button
                    key={book.id}
                    onClick={() => setSelectedBook(book)}
                    className={`w-full text-left p-3 rounded-lg border transition-all group ${
                      selectedBook?.id === book.id
                        ? 'border-phosphor-amber bg-phosphor-amber/10'
                        : 'border-white/10 hover:border-phosphor-amber/50 hover:bg-phosphor-amber/5'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-xl">📖</span>
                      <div className="flex-1 min-w-0">
                        <div className="font-rajdhani font-medium text-white truncate">
                          {book.name}
                        </div>
                        <div className="font-mono text-xs text-white/40">
                          {(book.size / 1024).toFixed(1)} KB
                        </div>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(book.id);
                        }}
                        className="opacity-0 group-hover:opacity-100 w-6 h-6 rounded bg-red-500/20 border border-red-500/40 text-red-400 flex items-center justify-center text-xs hover:bg-red-500/30 transition-all"
                      >
                        🗑
                      </button>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </motion.aside>

          {/* Main content */}
          <motion.main
            className="flex-1 holographic-card rounded-lg overflow-hidden flex flex-col"
            style={{ borderColor: '#f59e0b40' }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            {selectedBook ? (
              <>
                {/* Reader toolbar */}
                <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-void-black/50">
                  <h3 className="font-orbitron text-lg text-phosphor-amber truncate max-w-md">
                    {selectedBook.name}
                  </h3>
                  <div className="flex items-center gap-3">
                    {/* Font size controls */}
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setFontSize(s => Math.max(12, s - 2))}
                        className="w-8 h-8 rounded border border-white/20 text-white/60 hover:border-phosphor-amber hover:text-phosphor-amber flex items-center justify-center"
                      >
                        A-
                      </button>
                      <span className="font-mono text-xs text-white/40 w-8 text-center">{fontSize}px</span>
                      <button
                        onClick={() => setFontSize(s => Math.min(24, s + 2))}
                        className="w-8 h-8 rounded border border-white/20 text-white/60 hover:border-phosphor-amber hover:text-phosphor-amber flex items-center justify-center"
                      >
                        A+
                      </button>
                    </div>

                    {/* Theme toggle */}
                    <div className="flex gap-1">
                      {(['dark', 'light', 'sepia'] as ReaderTheme[]).map(theme => (
                        <button
                          key={theme}
                          onClick={() => setReaderTheme(theme)}
                          className={`px-3 py-1 rounded text-xs font-mono uppercase border transition-all ${
                            readerTheme === theme
                              ? 'border-phosphor-amber bg-phosphor-amber/20 text-phosphor-amber'
                              : 'border-white/20 text-white/50 hover:border-white/40'
                          }`}
                        >
                          {theme}
                        </button>
                      ))}
                    </div>

                    <GlitchButton variant="terminal" size="sm" onClick={() => setSelectedBook(null)}>
                      CLOSE
                    </GlitchButton>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="h-1 bg-white/10">
                  <motion.div
                    className="h-full bg-gradient-to-r from-phosphor-amber to-yellow-400"
                    style={{ width: `${scrollProgress}%` }}
                  />
                </div>

                {/* Content */}
                <div
                  ref={contentRef}
                  onScroll={handleScroll}
                  className="flex-1 overflow-auto p-8"
                  style={themeStyles[readerTheme]}
                >
                  <div
                    className="max-w-3xl mx-auto font-serif leading-relaxed whitespace-pre-wrap"
                    style={{ fontSize: `${fontSize}px`, lineHeight: '1.8' }}
                  >
                    {selectedBook.content}
                  </div>
                </div>

                {/* Page info */}
                <div className="px-4 py-2 border-t border-white/10 bg-void-black/50 font-mono text-xs text-white/40 text-center">
                  {Math.round(scrollProgress)}% // {selectedBook.content.split(/\s+/).length.toLocaleString()} words
                </div>
              </>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
                <div className="text-6xl mb-6 opacity-20">📚</div>
                <h3 className="font-orbitron text-2xl text-white/70 mb-3">
                  Your library awaits
                </h3>
                <p className="font-rajdhani text-white/50 max-w-md mb-6">
                  Import a <strong className="text-phosphor-amber">.txt</strong> or{' '}
                  <strong className="text-phosphor-amber">.md</strong> file to start reading.
                  Books are stored locally — private and instant.
                </p>
                <label>
                  <input
                    type="file"
                    accept=".txt,.md"
                    onChange={handleImport}
                    className="hidden"
                  />
                  <GlitchButton icon="📂">IMPORT YOUR FIRST BOOK</GlitchButton>
                </label>
              </div>
            )}
          </motion.main>
        </div>
      </div>
    </section>
  );
};
