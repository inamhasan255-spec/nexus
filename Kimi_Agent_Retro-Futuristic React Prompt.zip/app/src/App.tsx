import React, { useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useStore, type Section } from '@/store/useStore';
import { CRTWrapper } from '@/components/retro/CRTWrapper';
import { BootSequence } from '@/components/retro/BootSequence';
import { Navigation } from '@/components/retro/Navigation';
import { Starfield } from '@/components/retro/Starfield';
import { Dashboard } from '@/sections/Dashboard';
import { Journal } from '@/sections/Journal';
import { ParticleField } from '@/sections/ParticleField';
import { CodeVault } from '@/sections/CodeVault';
import { BiologyAI } from '@/sections/BiologyAI';
import { Books } from '@/sections/Books';
import { SecureFolder } from '@/sections/SecureFolder';
import { Cube3D } from '@/sections/Cube3D';
import { WaveText } from '@/sections/WaveText';

const SECTIONS: Record<Section, React.ComponentType> = {
  dashboard: Dashboard,
  journal: Journal,
  particles: ParticleField,
  code: CodeVault,
  biology: BiologyAI,
  books: Books,
  secure: SecureFolder,
  cube: Cube3D,
  wave: WaveText,
};

function App() {
  const { bootComplete, currentSection } = useStore();

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!bootComplete) return;
      
      const sections = Object.keys(SECTIONS) as Section[];
      const currentIndex = sections.indexOf(currentSection);
      
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
        const nextIndex = (currentIndex + 1) % sections.length;
        useStore.getState().setCurrentSection(sections[nextIndex]);
      } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        const prevIndex = (currentIndex - 1 + sections.length) % sections.length;
        useStore.getState().setCurrentSection(sections[prevIndex]);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [bootComplete, currentSection]);

  const CurrentSection = SECTIONS[currentSection];

  return (
    <CRTWrapper>
      {/* Boot sequence */}
      <AnimatePresence>
        {!bootComplete && <BootSequence />}
      </AnimatePresence>

      {/* Starfield background */}
      {bootComplete && <Starfield count={1500} speed={0.01} />}

      {/* Navigation */}
      {bootComplete && <Navigation />}

      {/* Main content */}
      {bootComplete && (
        <main className="relative z-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSection}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.3, ease: 'easeInOut' }}
            >
              <CurrentSection />
            </motion.div>
          </AnimatePresence>
        </main>
      )}

      {/* Footer status bar */}
      {bootComplete && (
        <motion.footer
          className="fixed bottom-0 left-0 right-0 h-8 bg-void-black/80 border-t border-white/10 flex items-center justify-between px-4 z-50"
          initial={{ y: 32 }}
          animate={{ y: 0 }}
          transition={{ delay: 1 }}
        >
          <div className="flex items-center gap-4">
            <span className="font-mono text-xs text-neon-cyan">
              NEXUS v2.0.77
            </span>
            <span className="font-mono text-xs text-white/30">
              |
            </span>
            <span className="font-mono text-xs text-white/50">
              {currentSection.toUpperCase()}
            </span>
          </div>
          <div className="flex items-center gap-4">
            <span className="font-mono text-xs text-neon-lime flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-neon-lime animate-pulse" />
              SYSTEM ONLINE
            </span>
            <span className="font-mono text-xs text-white/30">
              Use ← → to navigate
            </span>
          </div>
        </motion.footer>
      )}
    </CRTWrapper>
  );
}

export default App;
